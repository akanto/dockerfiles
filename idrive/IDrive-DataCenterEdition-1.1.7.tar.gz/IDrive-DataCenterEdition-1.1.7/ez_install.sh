#!/bin/bash
#
# Installs the datacenter application on the system
#
###################################################

#***************
# safety first
#***************
set -u # referencing to any non-defined variable (except $* and $@) is an error
set -o pipefail # prevents errors in a pipeline from being masked

#***************
# path
#***************
PATH="/usr/local/bin:${PATH}"

#***************
# constants
#***************
readonly LOG_FORMAT='+%Y-%m-%d %H:%M:%S%z'
readonly CWD="$(pwd)"

readonly PYTHON_IMPORT_LDB="__import__('idrive')"
APP_NAME=$(python -c "print ${PYTHON_IMPORT_LDB}.LONG_NAME;" 2>/dev/null)
readonly APP_NAME=${APP_NAME:-Datacenter Edition}
readonly APP_SHORT_NAME=$(python -c "print ${PYTHON_IMPORT_LDB}.SHORT_NAME;" 2>/dev/null)
readonly APP_PKG_NAME=$(python -c "print ${PYTHON_IMPORT_LDB}.PKG_NAME;" 2>/dev/null)
readonly LOG_FILE="/tmp/${APP_SHORT_NAME:-datacenter_edition}_install.log"

readonly YES='yes'
readonly NO='no'

readonly PYTHON='python2.7'
readonly PYTHON_NAME='Python 2.7'
readonly PYTHON_VERSION='2.7.9'
readonly PIP='pip2.7'

readonly SUCCESS=0
readonly E_NOT_ROOT=1
readonly E_WRONG_DISTRO=2
readonly E_SIGNAL=3
readonly E_DEPENDENCY_INSTALL_FAILED=4
readonly E_PYTHON_INSTALL_FAILED=5
readonly E_NO_PYTHON=6
readonly E_NO_PIP=7
readonly E_NO_APP=8
readonly E_PIP_NOT_UPDATED=9
readonly E_NO_LSB_RELEASE=10
readonly E_NO_SYSTEM_PYTHON=11

#***************
# functions
#***************

#---------------
# log it
# @param $1: log message
#---------------
function log_it() {
  echo "[$(date "${LOG_FORMAT}")]: ${1}" >> "${LOG_FILE}"
}

#---------------
# displays a status message
# @param $@: status message(s)
#---------------
function status() {
  local message=$*
  echo "${message}"
  log_it "${message}"
}

#---------------
# displays an error message
# @param $1: what happened
# @param $2: last command executed
#---------------
function error() {
  local message="ERROR: ${1:-An error occurred}" >&2
  local last_command="${2:-}"
  echo
  echo "${message}"
  log_it "${message}"

  if [[ -n "${last_command}" ]]; then
    last_command="Last command executed: ${last_command}"
    echo "${last_command}" >&2
    log_it "${last_command}"
  fi

  echo 'Check docs/install.txt docs/faqs.txt for help with installation'
  echo "A log of this install can be found at: ${LOG_FILE}"
  echo
}

#---------------
# displays an animated progress bar
# @param $1: pid to monitor
#---------------
function progress_bar {
  local pid="${1}"
  sleep 2
  while true; do
    if ! kill -0 "${pid}" 2>/dev/null; then
      break # the process has finished
    fi

    for _ in {0..10}; do
      echo -n '='
      sleep .2
    done
    echo -ne "\r           \r"
  done
  wait "${pid}"
}

#---------------
# signal handler
# @param $1: the signal to handle
#---------------
function handle_signal() {
  local signal="${1}"
  local last_background_process_pid="$!"
  status "Handling signal: ${signal}"

  if kill -0 "${last_background_process_pid}" 2>/dev/null; then
    log_it "Forwarding signal to child process: ${last_background_process_pid}"
    kill -s "${signal}" "${last_background_process_pid}"
  fi

  exit "${E_SIGNAL}"
}

#---------------
# super user check
#---------------
function is_root() {
  if [[ "$(whoami)" != 'root' ]]; then
    error 'You must be root to run this script.'
    exit "${E_NOT_ROOT}"
  fi
}

#---------------
# ensure system has at least some python installed
#---------------
function has_system_python() {
  if ! which python 1>/dev/null 2>&1; then
    error '"python" is not installed or not in your path'
    exit "${E_NO_SYSTEM_PYTHON}"
  fi
}

#---------------
# try to install lsb_release if it isn't before we begin
#---------------
function install_lsb() {
  if ! which lsb_release 1>/dev/null 2>&1; then
    log_it '"lsb_release" is not installed or not in the path. Attempting to install...'
    if which yum 1>/dev/null 2>&1; then
      yum install -y redhat-lsb-core >>"${LOG_FILE}" 2>&1
    elif which apt-get 1>/dev/null 2>&1; then
      apt-get -qq -y install lsb-release >>"${LOG_FILE}" 2>&1
    fi

    if ! which lsb_release 1>/dev/null 2>&1; then
      error '"lsb_release" not installed or not in your path'
      exit "${E_NO_LSB_RELEASE}"
    fi
  fi
}

#---------------
# is the os centos?
#---------------
function is_centos() {
  if [[ "$(lsb_release -i 2>&1)" == *"CentOS" ]]; then
    return 0
  fi

  return 1
}

#---------------
# is the os debian based?
#---------------
function is_debian() {
  local distributor_id
  distributor_id="$(lsb_release -i 2>&1)"

  if [[ "${distributor_id}" == *"Debian" || "${distributor_id}" == *"Ubuntu" ]]; then
    return 0
  fi

  return 1
}

#---------------
# is this OS an old version of centos? we do different things cuz it's ghetto
#---------------
function is_centos_5() {
  if is_centos; then
    if [[ "$(lsb_release -r 2>&1)" == *"5."* ]]; then
      return 0
    fi
  fi

  return 1
}

#---------------
# check linux distribution
#---------------
function check_distribution() {
  status 'Checking Linux distribution...'

  log_it 'System details:'
  {
    uname -a
    uname -m
    lsb_release -a
  } >> "${LOG_FILE}" 2>&1

  if is_centos || is_debian; then
    status 'Supported distribution found'
    return
  fi

  error 'This installation script only works on CentOS and Debian based Linux distributions'
  exit "${E_WRONG_DISTRO}"
}

#---------------
# get command to install packages on the system
#---------------
function get_package_install_command() {
  if is_centos; then
    echo 'yum install -q -y'
  else
    echo 'apt-get -qq -y install'
  fi
}

#---------------
# get command to check if packages are installed on the system
#---------------
function get_package_info_command() {
  if is_centos; then
    echo 'yum info -q'
  else
    echo ''
  fi
}

#---------------
# if debian based os, we want to update the package indexes
#---------------
function update_package_indexes() {
  if is_debian; then
    status 'Updating package indexes...'
    apt-get update >> "${LOG_FILE}" 2>&1 &
    progress_bar "$!"
  fi
}

#---------------
# install dependencies
# @param $1: who are we installing dependencies for?
# @param $@: what to install
#---------------
function install_dependencies() {
  local requestor="${1}"
  shift
  # shellcheck disable=SC2124
  local dependencies="$@"
  local pkg_install_cmd
  local pkg_info_cmd

  pkg_install_cmd="$(get_package_install_command)"
  pkg_info_cmd="$(get_package_info_command)"

  status "Installing dependencies for ${requestor}. This may take some time..."
  log_it "Installing dependencies: ${dependencies[*]}"

  # install them
  # shellcheck disable=SC2086
  $pkg_install_cmd ${dependencies[*]} >>"${LOG_FILE}" 2>&1 &
  progress_bar "$!"
  if [[ "$?" -ne 0 ]]; then
    error "Installing dependencies for ${requestor} failed" \
      "${pkg_install_cmd} ${dependencies[*]}"
    exit "${E_DEPENDENCY_INSTALL_FAILED}"
  fi

  # verify dependency install
  if [[ -n "${pkg_info_cmd}" ]]; then
    for dependency in ${dependencies[*]}; do
      log_it "Checking that dependency ${dependency} was installed for ${requestor}"
      $pkg_info_cmd "${dependency}" >>"${LOG_FILE}" 2>&1
      if [[ "$?" -ne 0 ]]; then
        error "Installing dependency \"${dependency}\" failed for ${requestor}" \
          "${pkg_info_cmd} ${dependency}"
        exit "${E_DEPENDENCY_INSTALL_FAILED}"
      fi
    done
  fi

  status "${requestor} dependencies installed"
}

#---------------
# is python 2.7 installed?
# @param $1: display output?
#---------------
function is_python_installed() {
  local verbose="${1:-}"

  if [[ -n "${verbose}" ]]; then
    status "Checking if ${PYTHON_NAME} is installed..."
  fi

  which $PYTHON 1>/dev/null 2>&1
  return "$?"
}

#---------------
# install python
# @param $1: python package
# @param $2: download url
#---------------
function install_python() {
  local python_package="${1}"
  local python_download_url="${2}"
  local tempdir

  tempdir="$(mktemp -d)"
  if ! cd "${tempdir}"; then
    error 'Could not cd into tempdir to install python' "cd \"${tempdir}\""
    exit "${E_PYTHON_INSTALL_FAILED}"
  fi

  # download
  status "Downloading ${python_package}..."
  wget --no-check-certificate "${python_download_url}" -q -O - | tar -xzf - &
  progress_bar "$!"
  if [[ "$?" -ne 0 ]]; then
    echo
    error "Downloading ${python_package} failed"
    cd "${CWD}" && rm -rf "${tempdir}"
    exit "${E_PYTHON_INSTALL_FAILED}"
  fi

  # configure
  status "Configuring ${python_package}..."
  if ! cd "${python_package}"; then
    error 'Could not cd into python package' "cd \"${python_package}\""
    exit "${E_PYTHON_INSTALL_FAILED}"
  fi
  ./configure >>"${LOG_FILE}" 2>&1 &
  progress_bar "$!"

  # install
  status "Installing ${python_package}..."
  make install >>"${LOG_FILE}" 2>&1 &
  progress_bar "$!"
  if [[ "$?" -ne 0 ]]; then
    echo
    error 'Python installation failed'
    cd "${CWD}" && rm -rf "${tempdir}"
    exit "${E_PYTHON_INSTALL_FAILED}"
  fi

  cd "${CWD}" && rm -rf "${tempdir}"
  status "${python_package} installed"
}

#---------------
# prompt for python installation and proceed if allowed
#---------------
function prompt_and_install_python() {
  local python_install_required="${NO}"
  local python_package="Python-${PYTHON_VERSION}"
  local python_download_url="https://www.python.org/ftp/python/${PYTHON_VERSION}/${python_package}.tgz"
  local python_dependencies=('gcc' 'zlib-devel' 'openssl-devel' 'python-devel')

  if ! is_centos; then
    return # we only support installing updated python on centos
  fi

  log_it "${PYTHON_NAME} not found. Asking to install..."

  echo
  echo "${PYTHON_NAME} was not found on your system. This script can"
  echo 'automatically install it for you on your system. By choosing'
  echo 'yes ("y"), the following actions will be taken:'
  echo
  echo "  1. $(get_package_install_command) ${python_dependencies[*]}"
  echo "  2. Download ${python_package} from ${python_download_url}"
  echo "  3. Install ${python_package} into /usr/local on the system"
  echo

  while true; do
    echo -n "Would you like to install ${python_package}? [y/N] "
    local answer
    read -r answer
    if [[ "${answer}" =~ ^[yY] ]]; then
      log_it "${PYTHON_NAME} install approved"
      python_install_required="${YES}"
      break
    elif [[ -z "${answer}" || "${answer}" =~ ^[nN] ]]; then
      log_it "${PYTHON_NAME} install denied"
      break
    fi
  done

  # python 2.7 installation
  if [[ "${python_install_required}" != "${YES}" ]]; then
    return
  fi

  install_dependencies "${PYTHON_NAME}" "${python_dependencies[*]}"
  install_python "${python_package}" "${python_download_url}"
}

#---------------
# install datacenter application dependencies
#---------------
function install_app_dependencies() {
  local app_dependencies

  # debian
  if is_debian; then
    app_dependencies=('gcc' 'libgmp-dev' 'python-dev' 'libffi-dev' 'python-pip' 'libssl-dev')
  # centos 5.x
  elif is_centos_5; then
    app_dependencies=('gcc' 'gmp-devel' 'python-devel' 'openssl-devel')
  # centos 6.+
  else
    app_dependencies=('gcc' 'gmp-devel' 'python-devel' 'libffi-devel' 'openssl-devel')
  fi

  install_dependencies "${APP_NAME}" "${app_dependencies[*]}"
}

#---------------
# is pip installed?
# @param $1: display output?
#---------------
function is_pip_installed() {
  local verbose="${1:-}"

  if [[ -n "${verbose}" ]]; then
    status 'Checking if pip is installed...'
  fi

  which $PIP 1>/dev/null 2>&1
  return "$?"
}

#---------------
# install pip
#---------------
function install_pip() {
  local tempdir

  status 'Installing pip...'

  tempdir="$(mktemp -d)"
  if ! cd "${tempdir}"; then
    error 'Could not cd into tempdir to install pip' "cd \"${tempdir}\""
    exit "${E_NO_PIP}"
  fi


  # download
  wget --no-check-certificate 'https://bootstrap.pypa.io/get-pip.py' -q
  if [[ "$?" -ne 0 ]]; then
    error 'pip not downloaded'
    exit "${E_NO_PIP}"
  fi

  # install
  $PYTHON get-pip.py --trusted-host pypi.python.org >>"${LOG_FILE}" 2>&1
  if [[ "$?" -ne 0 ]]; then
    error 'pip installation failed'
    cd "${CWD}" && rm -rf "${tempdir}"
    exit "${E_NO_PIP}"
  fi
  cd "${CWD}" && rm -rf "${tempdir}"
}

#---------------
# upgrade pip to the latest version
#---------------
function upgrade_pip() {
  # older centos needs older pip. see bug #388
  if is_centos_5; then
    log_it 'Downgrading pip for CentOS 5.X'
    $PIP install pip==6.1.1 >>"${LOG_FILE}" 2>&1
  else
    # try the newer syntax
    $PIP install --upgrade --trusted-host pypi.python.org pip >>"${LOG_FILE}" 2>&1
    if [[ "$?" -ne 0 ]]; then
      # older version of pip, it's ok we don't need to explicitly trust the host
      $PIP install --upgrade pip >>"${LOG_FILE}" 2>&1
      if [[ "$?" -ne 0 ]]; then
        error 'Could not update pip' "${PIP} install --upgrade pip"
        exit "${E_PIP_NOT_UPDATED}"
      fi
    fi
  fi

}

#---------------
# install datacenter application
#---------------
function install_app() {
  if ! cd "${CWD}"; then
    error 'Could not cd into application directory' "cd \"${CWD}\""
    exit "${E_NO_APP}"
  fi

  if [[ ! -f 'setup.py' ]]; then
    error "All dependencies installed but did not find any package to install ${APP_NAME}"
    exit "${E_NO_APP}"
  fi

  status "Installing ${APP_NAME}..."

  $PIP install --trusted-host pypi.python.org . >>"${LOG_FILE}" 2>&1 &
  progress_bar "$!"
  if [[ "$?" -ne 0 ]]; then
    error "Installing ${APP_NAME} failed"
    exit "${E_NO_APP}"
  fi

  # show success
  clear
  echo "Installation of ${APP_NAME} was successful."
  echo
  echo "For accessing ${APP_NAME} from outside this system,"
  echo "you may need to open up the port that ${APP_NAME} runs on."
  echo 'For more information on configuring your firewall, please'
  echo 'read docs/faqs.txt.'
  echo
  echo "To start using ${APP_NAME}, execute $(which "${APP_SHORT_NAME}"_admin.py)"

  log_it "${APP_NAME} installed successfully"
}

#---------------
# main
#---------------
function main() {
  status "Starting ${APP_NAME} installation..."

  # sanity checks
  is_root
  has_system_python

  # register signal handler to kill background processes
  trap 'handle_signal SIGINT' SIGINT
  trap 'handle_signal SIGTERM' SIGTERM

  # start
  install_lsb
  check_distribution
  update_package_indexes

  # python
  if ! is_python_installed 'verbose'; then
    prompt_and_install_python

    if ! is_python_installed; then
      error "Cannot continue without ${PYTHON_NAME}. It is not installed or not in your path."
      exit "${E_NO_PYTHON}"
    fi
  fi
  status "${PYTHON_NAME} found at: $(which "${PYTHON}")"

  install_app_dependencies

  # pip
  if ! is_pip_installed 'verbose'; then
    install_pip
    if ! is_pip_installed; then
      error 'pip is not installed or not in your path'
      exit "${E_NO_PIP}"
    fi
  fi
  upgrade_pip
  status "${PIP} found at: $(which "${PIP}")"

  # the install
  install_app

  log_it "${APP_NAME} installation completed successfully"
  exit "${SUCCESS}"
}

#***************
# away we go!
#***************
main
