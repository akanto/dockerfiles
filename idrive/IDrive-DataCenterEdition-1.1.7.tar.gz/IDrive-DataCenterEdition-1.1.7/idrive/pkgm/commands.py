"""Package manager commands"""

import os
import subprocess
import re
import sys
import lockfile
import atexit

from daemon.pidfile import TimeoutPIDLockFile

from idrive import SHORT_NAME, PKG_NAME
from idrive.conf.settings import GlobalSettings


_G = GlobalSettings()
_SCRIPTS = {
    'proxy.py': False,
    'websrvr.py': False,
    'sched.py': False
}
_SCRIPTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'bin')

_LOCK_FILE = "/tmp/{}_upgrade".format(SHORT_NAME)


def _execute_pip(command):
    '''
    Executes pip to do different operations
    '''
    pip = '/usr/bin/pip2.7'
    if not os.path.exists(pip):
        pip = '/usr/local/bin/pip2.7'

        if not os.path.exists(pip):
            raise RuntimeError('pip not found')

    args = [pip]
    if command == 'version_check':
        args.extend(['list', '--outdated'])
    elif command == 'sw_update':
        args.extend(['install', PKG_NAME.lower(), '--upgrade'])
    else:
        raise ValueError('Invalid command "{}"'.format(command))

    args.extend(['--index-url', _G.PKGM.index_url])

    try:
        output = subprocess.check_output(args, stderr=subprocess.PIPE)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(e.output)

    result = None
    name_re = re.compile('^' + re.escape(PKG_NAME) + '[ =]')
    if command == 'version_check':
        for line in output.splitlines():
            if name_re.match(line) is not None:
                result = line
                break
    elif command == 'sw_update':
        try:
            args = [pip, 'freeze']
            output = subprocess.check_output(args, stderr=subprocess.PIPE)
        except subprocess.CalledProcessError:
            pass
        else:
            for line in output.splitlines():
                if name_re.match(line) is not None:
                    result = line
                    break

            if result is not None:
                result = result.split('==')[1]

    return result


def upgrade():
    '''
    Updates the package to latest version

    It will first check if any backup/restore is running before
    initiating an upgrade. It also takes care of stopping. The services
    if they are already running upgrade and restarts the services after
    upgrade if they were running before upgrade.

    @raise RuntimeError:
        If backup/restore is running, another upgrade is running, command was
        executed by non super user.
    @raise KeyError:
        No new version available for upgrade
    @return: New version of the software as string
    '''
    if os.getegid() != 0:
        raise RuntimeError('Must be executed by superuser')

    # Verify new version exists to upgrade to
    if _execute_pip('version_check') is None:
        raise KeyError('No new version available for upgrade')

    # check if backup/restore running
    if _SCRIPTS['sched.py']:
        # if backup_restore_running:
            # raise RuntimeError("Backup or restore running")
        pass

    # check if subsystems are running to restart after upgrade
    for script in _SCRIPTS.keys():
        script_path = os.path.join(_SCRIPTS_DIR, script)
        try:
            subprocess.check_call([sys.executable, script_path, '--status'])
        except subprocess.CalledProcessError:
            pass
        else:
            subprocess.check_call([sys.executable, script_path, '--stop'])
            _SCRIPTS[script] = True

    # Only one upgrade process should run
    pid_file = TimeoutPIDLockFile(_LOCK_FILE, -0.001)
    try:
        pid_file.acquire()
    except lockfile.AlreadyLocked:
        raise RuntimeError('Another upgrade is running. PID {}'.
                           format(pid_file.read_pid()))

    atexit.register(pid_file.release)

    # do upgrade
    try:
        result = _execute_pip('sw_update')
    except RuntimeError:
        raise
    finally:
        for script, needs_restart in _SCRIPTS.iteritems():
            if not needs_restart:
                continue

            script_path = os.path.join(_SCRIPTS_DIR, script)
            try:
                subprocess.check_call([sys.executable, script_path, '--start'])
            except subprocess.CalledProcessError:
                pass

    return result


def check_upgrade():
    '''
    Check if new version of software is available for upgrade
    '''
    version_string = _execute_pip('version_check')

    if version_string is None:
        raise KeyError('No new version available for upgrade')

    return re.sub(r'.*Latest: ([\d\.]+[a-z]*).*\)$', '\\1', version_string)
