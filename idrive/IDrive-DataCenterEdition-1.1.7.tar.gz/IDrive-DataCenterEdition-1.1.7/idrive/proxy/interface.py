"""Interface to interact with the scheduler daemon."""

import socket
from multiprocessing.connection import Client, AuthenticationError

import idrive.utils.log as log
from idrive.conf.settings import GlobalSettings

import idrive.proxy.proxy_main as proxy_main


def _send_command_to_proxy(command_details):
    """Internal function to send job to server."""

    g = GlobalSettings()
    try:
        host = g.PROXY.host
    except AttributeError:
        log.warning("Could not get proxy server host from conf")
        log.warning("Connecting to default 'localhost'")
        host = 'localhost'

    try:
        port = int(g.PROXY.port)
    except (AttributeError, ValueError):
        log.warning("Could not get proxy server port from conf")
        log.warning("Connecting to default port '55000'")
        port = 55000

    log.debug("Connecting to proxy at {}:{}"
              .format(host, port), mod_name=__name__)
    try:
        connection = Client((host, port), authkey=proxy_main._AUTHKEY)
    except socket.error:
        raise RuntimeError("Proxy daemon not running")
    except AuthenticationError:
        raise RuntimeError("Proxy may not be running on default port")

    log.debug("Sending command to proxy", mod_name=__name__)
    connection.send(command_details)

    return connection


def passthru(username, password, command, args):
    """Send a command via proxy.

    username/password are for the local system.

    command is a string which defines the mapping in
    proxy/private/command_mappings.json.

    args should be a dict and have the following structure

    If command maps to a module.function
    args = {'params': (<arg list>)}
    <arg list> must be () if module.function doesn't accept any parameters

    If command maps to a module.Class definition
    args = {'init_params': (<init arg list>),
            'method': <method>, 'params': (arg list)}
    <init arg list> is the parameter for the class constructor.
    'method' is optional, which represents the method of the class to execute
    after instantiating the class. The result will be returned in this case.
    'params' must be present (even if empty) if 'method' is passed.
    If 'method' is not passed, the object created from module.Class will be
    returned, otherwise the return value of 'method' will be returned.

    """

    if not isinstance(args, dict):
        raise ValueError("Invalid args : {}".format(str(args)))

    log.debug("Trying to send command {} to proxy'"
              .format(command), mod_name=__name__)
    connection = _send_command_to_proxy([username, password, command, args])

    return_data = None
    try:
        return_data = connection.recv()
    except EOFError:
        log.debug("No data received from proxy", mod_name=__name__)
    else:
        log.debug("Proxy returned data", mod_name=__name__)

    return return_data
