"""Proxy callbacks entry point"""

from multiprocessing import Process, Pipe

from idrive.proxy.private.command_processor import process_command
from idrive.utils import log

_CHILD_RETY_TIMEOUT = 5  # Connection.poll() timeout
_CHILD_RETRY_MAX = 20  # Max retry before killing child and exiting


def proxy_callback(callback_data):
    """Entry point of proxy command processing

    Does few basic validations and invokes a sub process to do
    the actual job. The child process will lower privileges before
    doing it task.

    """

    log.debug("Proxy callback received data", mod_name=__name__)

    result = None
    if not isinstance(callback_data, list):
        msg = "Invalid params, input is not a list"
        log.error(msg)
        raise ValueError(msg)

    if len(callback_data) < 4:
        msg = "Insufficient data passed as params"
        log.error(msg)
        raise ValueError(msg)

    username = callback_data[0]
    password = callback_data[1]
    command = callback_data[2]
    args = callback_data[3]

    conn_recv, conn_send = Pipe(False)
    command_processor = Process(target=process_command,
                                args=(username, password, command, args,
                                      conn_send))
    command_processor.start()

    # We will not wait forever for child to return data
    for _ in range(_CHILD_RETRY_MAX):
        if conn_recv.poll(_CHILD_RETY_TIMEOUT):
            try:
                result = conn_recv.recv()
            except EOFError as err:
                log.error(err, mod_name=__name__)
            finally:
                break
        elif not command_processor.is_alive():
            log.error("Child died without sending data", mod_name=__name__)
            break
    else:
        error_str = "Child running for too long. Will terminate child"
        log.error(error_str, mod_name=__name__)
        command_processor.terminate()

        raise RuntimeError(error_str)

    command_processor.join(_CHILD_RETY_TIMEOUT)

    return result
