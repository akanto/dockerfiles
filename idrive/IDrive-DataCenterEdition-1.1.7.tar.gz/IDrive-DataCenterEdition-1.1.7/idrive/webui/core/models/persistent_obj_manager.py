"""Stores objects accross session."""

import os
import atexit
import tempfile
import pickle
import threading
from datetime import datetime, timedelta

from idrive.utils.singleton import MetaSingleton
from idrive.utils.encryption import encrypt_data, decrypt_data
from idrive.webui import DEBUG

SAVE_POM_TO_DISK = DEBUG


class PersistentObjManager(object):
    """Stores objects across sessions.

    POM is a dictionary index by 'key' and stores objects against
    'obj_key' in an inner dictionary. In addition
    it also stores a timer and timeout data to clear stale values in
    the object store dictionary. The inner dictionary together with
    the thread and timeout data is the 'object store'

    Following is how the object store looks. '
    key', and 'obj_key_n' are passed from outside.

    'key': {
        _OBJECTS: {'obj_key_1': <obj_1>, ... 'obj_key_n': <obj_n>},
        _LMT: <last accessed time for 'key',
        _GC_THREAD: <thread which removes _OBJECTS after _LMT
    }

    """

    # NOTE : Flask must run only one instance for POM to work

    __metaclass__ = MetaSingleton

    # object store keys
    _LMT = 'lmt'  # key for storing last modified time
    _OBJECTS = 'objects'  # key for storing outside objects
    _GC_THREAD = 'gc_thread'  # key for storing the gc thread

    _STORE_FILENAME = 'pom.data'
    _OBJ_STORE_TIMEOUT = timedelta(0, 3600)  # 1 hour

    KEY_NAME = 'key'  # For use by clients to store the key against a name

    def __init__(self):
        """Constructor"""

        self._obj_store = {}

        data_file = tempfile.gettempdir() + os.path.sep + self._STORE_FILENAME
        if os.path.exists(data_file):
            try:
                with open(data_file, 'r') as f:
                    self._obj_store = pickle.loads(decrypt_data(f.read()))
            except Exception:
                pass

            os.unlink(data_file)

        # start the gc threads
        for key in self._obj_store:
            self._start_gc(key)

    def __del__(self):
        """Destructor."""

        self._cleanup()

    def _cleanup(self, save_to_disk=SAVE_POM_TO_DISK):
        """Removes stale obj from obj store.

        By default, also saves object store to disk.

        """

        # Note: Don't move this to __del__

        now = datetime.now()
        for key in self._obj_store.keys():
            lmt = self._obj_store[key][self._LMT]
            if now - lmt >= self._OBJ_STORE_TIMEOUT:
                # stop the gc thread before deleting the obj store
                if self._GC_THREAD in self._obj_store[key]:
                    self._obj_store[key][self._GC_THREAD].cancel()
                del self._obj_store[key]

        if self._obj_store and save_to_disk:

            # stop all GC threads before syncing to disk
            for key in self._obj_store:
                self._obj_store[key][self._GC_THREAD].cancel()
                del self._obj_store[key][self._GC_THREAD]

            data_file = os.path.join(tempfile.gettempdir(),
                                     self._STORE_FILENAME)

            try:
                with open(data_file, 'w') as f:
                    f.write(encrypt_data(pickle.dumps(self._obj_store)))
            except Exception:
                pass

    def _start_gc(self, key):
        """Starts a thread to cleanup obj store of stale keys
        after _OBJ_STORE_TIMEOUT seconds.

        This method must be called by set(), get() and remove() on
        every successful operation.

        """

        if self._GC_THREAD in self._obj_store[key]:
            self._obj_store[key][self._GC_THREAD].cancel()
            del self._obj_store[key][self._GC_THREAD]

        # start a thread to call self._cleanup on timeout
        gc_thread = threading.Timer(self._OBJ_STORE_TIMEOUT.total_seconds(),
                                    self._cleanup, (False,))
        gc_thread.daemon = True  # Else main thread hangs during exit
        gc_thread.start()

        # store the thread to use later, like for canceling
        self._obj_store[key][self._GC_THREAD] = gc_thread

    def set(self, key, obj_name, obj):
        """Sets an object against key, obj_name."""

        if key not in self._obj_store:
            self._obj_store[key] = {self._LMT: None, self._OBJECTS: {}}

        self._obj_store[key][self._LMT] = datetime.now()
        self._obj_store[key][self._OBJECTS][obj_name] = obj
        self._start_gc(key)

    def get(self, key, obj_name):
        """Get an already set object."""

        if key not in self._obj_store:
            raise KeyError("'{}' not found".format(key))

        if obj_name not in self._obj_store[key][self._OBJECTS]:
            raise KeyError("'{}' not found".format(obj_name))

        self._obj_store[key][self._LMT] = datetime.now()

        self._start_gc(key)
        return self._obj_store[key][self._OBJECTS][obj_name]

    def remove(self, key, obj_name=None):
        """Remove an object or all objects if obj_name is None."""

        if obj_name is None:
            # cancel the GC thread if removing the whole obj store
            if self._GC_THREAD in self._obj_store[key]:
                self._obj_store[key][self._GC_THREAD].cancel()

            del self._obj_store[key]
        else:
            del self._obj_store[key][self._OBJECTS][obj_name]
            self._start_gc(key)

    def key_exists(self, key):
        """Utility function to check if a key exists in persistent storage."""

        exists = key in self._obj_store
        if exists:
            self._start_gc(key)

        return exists


@atexit.register
def _sync_objstore():
    """Internal function to sync obj store to disk."""

    PersistentObjManager()._cleanup()
