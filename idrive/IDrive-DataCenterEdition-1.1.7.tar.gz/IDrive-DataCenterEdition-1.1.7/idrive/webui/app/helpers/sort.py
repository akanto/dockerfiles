'''Sorting helpers'''

import os


def by_type(item):
    return 1 if item.isfile else 0


def by_name(item):
    return os.path.basename(item.name)


def by_size(item):
    return item.size if item.isfile else -1


def by_lmd(item):
    return int(item.modified_date.strftime('%s'))
