'''Reusable custom form validations'''

from wtforms.validators import ValidationError, EqualTo
from idrive.utils.validations import valid_path


class ValidPath(object):
    """
    Validates a path
    """
    def __init__(self, message=None):
        self.message = message

    def __call__(self, form, field):
        if not valid_path(field.data):
            message = self.message
            if message is None:
                message = field.gettext('Invalid path')

            raise ValidationError(message)


class NotEqualTo(EqualTo):
    """
    Verifies field is not equal to another field
    """

    def __call__(self, form, field):
        try:
            other = form[self.fieldname]
        except KeyError:
            raise ValidationError(field.gettext("Invalid field name '%s'.") %
                                  self.fieldname)
        if field.data == other.data:
            d = {
                'other_label': (hasattr(other, 'label') and other.label.text
                                or self.fieldname),
                'other_name': self.fieldname
            }
            message = self.message
            if message is None:
                message = field.gettext('Field must not equal to ' +
                                        '%(other_name)s.')

            raise ValidationError(message % d)
