"""Controller for logs"""

import datetime

from flask import Blueprint, flash, render_template, request, jsonify, \
    session, current_app

from idrive.webui.app.controllers import require_login, INTERNAL_ERROR_TXT
from idrive.webui.app.forms.logs import RecordIdForm
from idrive.webui.app.helpers import jsonify_error
from idrive.webui.app.models import session_log_interface
from idrive.webui.app.models import user_settings
from idrive.webui.core.models import PersistentObjManager


bp = Blueprint('logs', __name__, url_prefix='/logs')
bp.before_request(require_login)

POM = PersistentObjManager()


@bp.route('', methods=['GET'])
def index():
    '''
    log index page
    '''
    error = None
    key = session[POM.KEY_NAME]
    user_quota = user_settings.get(key, True).QUOTA

    try:
        log_records = session_log_interface.get_sorted_log_records(key)
    except (ValueError, RuntimeError) as e:
        log_records = []
        current_app.logger.error(unicode(e))
        if isinstance(e, ValueError):
            error = unicode(e)
        else:
            error = INTERNAL_ERROR_TXT
        flash(error, 'notify_danger')

    logs_html = render_template('logs/all.html', log_records=log_records,
                                error=error)

    return render_template('logs/index.html', logs=True, log_records=logs_html,
                           quota=user_quota)


@bp.route('/details/<logid>', methods=['GET'])
def details(logid=None):
    """Get details of a log record."""
    form = RecordIdForm(request.form, record_id=logid)

    try:
        if not form.validate():
            raise ValueError()

        log_record_id = str(form.record_id.data)

        log_record, details = \
            session_log_interface.get_record_details(session[POM.KEY_NAME],
                                                     log_record_id)

    except KeyError as e:
        current_app.logger.debug(unicode(e))
        return jsonify_error(render_template('jsons/error.json', form=form,
                                             reason=('Log record details '
                                                     'not found')))
    except (ValueError, RuntimeError) as e:
        current_app.logger.error(unicode(e))
        error = INTERNAL_ERROR_TXT
        if isinstance(e, ValueError):
            error = unicode(e)
        return jsonify_error(render_template('jsons/error.json', form=form,
                                             reason=error))

    return jsonify(html=render_template('logs/details.html', record=log_record,
                                        details=details, id=log_record_id))


@bp.route('/latest/backup', methods=['GET'],
          defaults={'operation': 'backup'})
@bp.route('/latest/backup/summary', methods=['GET'],
          defaults={'operation': 'backup', 'summary': True})
def latest_log_for_operation(operation, summary=False):
    """Get the latest log for operation backup/restore"""
    key = session[POM.KEY_NAME]

    try:
        if operation != 'backup':
            raise ValueError("Invalid operation")

        records = session_log_interface.get_sorted_log_records(key, None)
    except ValueError as e:
        current_app.logger.error(unicode(e))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=unicode(e)))
    except RuntimeError as err:
        current_app.logger.error(unicode(err))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))

    latest_log = {}
    for record in records:
        if record.operation == operation:
            latest_log = {'operation': record.operation,
                          'success': record.op_successful,
                          'cancelled': record.op_cancelled,
                          'username': record.username,
                          'computer_name': record.computer_name,
                          'start_time': record.op_start_time.strftime("%c"),
                          'end_time': record.op_end_time.strftime("%c"),
                          'id': record.op_details_id}
            break

    if not summary:
        return jsonify(latest_log)
    else:
        last_operation = {'success': None, 'end_time': None, 'days_ago': None}

        last_operation['success'] = latest_log['success']
        end_time = datetime.datetime.strptime(latest_log['end_time'], "%c")
        start_time = datetime.datetime.strptime(latest_log['start_time'], "%c")
        last_operation['end_time'] = end_time.strftime('%A, %B %d at %I:%M %p')
        last_operation['days_ago'] = \
            (datetime.date.today() - start_time.date()).days

        content = render_template('backup_restore/last_{}_panel.html'
                                  .format(operation),
                                  last_operation=last_operation)

        return jsonify(html=content)
