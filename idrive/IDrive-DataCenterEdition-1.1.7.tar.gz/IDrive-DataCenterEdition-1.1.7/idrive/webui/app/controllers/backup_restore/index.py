"""Backup/Restore index page."""

import json
import datetime
import urllib

from flask import session, render_template, current_app, Response, redirect, \
    url_for, request

from idrive.scheduler.private.ap_scheduler import BACKUP_JOB
from idrive.webui.app.models import backup_restore_set
from idrive.webui.app.models.quota import get_quota
from idrive.webui.app.models import user_settings
from idrive.webui.app.forms.browse_search import BrowseSearchForm
from idrive.webui.app.controllers.backup_restore.location import \
    get as get_location
from idrive.webui.app.controllers.schedule import get as get_schedule
from idrive.webui.app.controllers.logs import latest_log_for_operation

from . import bp_backup, bp_restore, POM
from idrive.utils.bunch import Bunch


def _get_quota():
    '''
    Get quota from EVS, or remote settings, whichever is available
    '''
    key = session[POM.KEY_NAME]
    max_quota = 0
    used_quota = 0
    percent = 0
    settings = user_settings.get(key)
    store_quota = False

    try:
        quota = get_quota(key)
    except (ValueError, RuntimeError) as e:
        current_app.logger.debug(unicode(e))

        if not hasattr(settings, 'QUOTA'):
            # if user settings doesn't have quota, set defaults as 0
            store_quota = True
    else:
        max_quota = quota.MAX_QUOTA
        used_quota = quota.USED_QUOTA
        percent = quota.PERCENT
        store_quota = True

    if store_quota:
        user_settings.update_remote(key, 'QUOTA', 'max_quota', max_quota)
        user_settings.update_remote(key, 'QUOTA', 'used_quota', used_quota)
        user_settings.update_remote(key, 'QUOTA', 'percent', percent)

    return user_settings.get(key, True).QUOTA


@bp_backup.route('', methods=['GET'], endpoint='index',
                 defaults={'from_': 'local'})
@bp_restore.route('', methods=['GET'], endpoint='index',
                  defaults={'from_': 'remote'})
@bp_restore.route('/search', endpoint='search', methods=['GET'],
                  defaults={'from_': 'remote', 'is_search': True})
@bp_restore.route('/trash', endpoint='trash-g', methods=['GET'],
                  defaults={'from_': 'remote', 'is_trash': True})
def index(from_, is_search=False, is_trash=False):
    """Backup/Restore index page"""

    if is_trash:
        return redirect(url_for('restore.index') + '#trash')

    if is_search:
        search_key = BrowseSearchForm(request.args).q.data.encode('utf-8')
        return redirect(url_for('restore.index') + '#search?q=' +
                        urllib.quote(search_key))

    local = (from_ is 'local')
    remote = (not local)
    set_type = backup_restore_set.RESTORE_SET
    if local:
        set_type = backup_restore_set.BACKUP_SET

    try:
        quota = _get_quota()
    except (ValueError, RuntimeError) as e:
        current_app.logger.error(unicode(e))
        quota = Bunch({'percent': 0, 'max_quota': 0, 'used_quota': 0})

    key = session[POM.KEY_NAME]
    br_set = set()
    try:
        set_ = backup_restore_set.get(key, set_type)
        br_set = set_.dir_entry_set
    except RuntimeError as err:
        current_app.logger.debug(unicode(err))

    schedule = None
    if local:
        backup_schedule = get_schedule(BACKUP_JOB)
        if isinstance(backup_schedule, Response):
            schedule = json.loads(backup_schedule.data)
        else:
            # error is returned as a tuple with first param
            #  as the json with error
            schedule = json.loads(backup_schedule[0])

    location = get_location(set_type)
    if isinstance(location, Response):
        location = json.loads(location.data)
        br_location = location['path']
    else:
        location = json.loads(location[0])
        br_location = None

    # Get the last backup operation status
    last_backup = {'success': None, 'end_time': None, 'days_ago': None}

    latest_log = latest_log_for_operation('backup')
    if isinstance(latest_log, Response):
        latest_log = json.loads(latest_log.data)

        if latest_log:
            last_backup['success'] = latest_log['success']
            last_backup['cancelled'] = latest_log['cancelled']
            end_time = datetime.datetime.strptime(latest_log['end_time'], "%c")
            start_time = datetime.datetime.strptime(latest_log['start_time'],
                                                    "%c")
            last_backup['end_time'] = \
                end_time.strftime('%A, %B %d at %I:%M %p')
            last_backup['days_ago'] = \
                (datetime.date.today() - start_time.date()).days

    return render_template('backup_restore/index.html', quota=quota,
                           backup=local, restore=remote,
                           br_set=br_set, br_location=br_location,
                           schedule=schedule, last_operation=last_backup)
