'''ldb.webui.app.forms.widgets.radio'''

from wtforms.widgets import HTMLString


class LDBRadioWidget(object):

    def __call__(self, field, **kwargs):
        html = []
        for subfield in field:
            html.append('<div class="radio"><label>%s %s</label></div>' %
                        (subfield(**kwargs), subfield.label.text))
        return HTMLString(u''.join(html))
