'''ldb.webui.app.forms.proxy'''

import re

from wtforms import Form, StringField, HiddenField
from wtforms.validators import InputRequired, NumberRange, Optional, Regexp

from idrive.webui.app.forms.fields.empty_integer_field import EmptyIntegerField
from idrive.webui.app.forms.fields.proxy import ProxyChoice
from idrive.webui.app.forms.validators.optional_unless import OptionalUnless


class ProxyForm(Form):
    NETWORKPROXY_proxy = \
        ProxyChoice(u'Network Proxy',
                    description=(u'Enter your proxy settings if your system '
                                 'connects to the internet through a proxy'),
                    validators=[InputRequired()],
                    choices=[('no', u'No Proxy'), ('manual', u'Manual Proxy')])

    NETWORKPROXY_host = StringField(
        u'Proxy Hostname',
        validators=[OptionalUnless('NETWORKPROXY_proxy',
                                   required_value='manual'),
                    Regexp(r'^[^ ]+$', re.IGNORECASE, message='Invalid host')])

    NETWORKPROXY_port = EmptyIntegerField(
        u'Proxy Port',
        validators=[OptionalUnless('NETWORKPROXY_proxy',
                                   required_value='manual'),
                    NumberRange(1, 65535, 'Not a valid port number')])

    NETWORKPROXY_username = StringField(
        u'Proxy Username', validators=[Optional()])

    # don't set to a "PasswordField", we want the value to pass through
    NETWORKPROXY_password = StringField(
        u'Proxy Password', validators=[Optional()])

    next = HiddenField(
        u'Next Location',
        validators=[Regexp(r'^/.*$', re.IGNORECASE,
                           message=u'Invalid location')],
        default='/')

    def validate_next(self, field):
        '''
        any errors w/ the next location, set it's default
        '''
        if field.errors:
            field.data = field.default
