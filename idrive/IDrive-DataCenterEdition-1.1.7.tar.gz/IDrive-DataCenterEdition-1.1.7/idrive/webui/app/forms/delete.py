'''delete validation form'''

from wtforms import Form, StringField, FieldList, BooleanField
from wtforms.validators import InputRequired

from idrive.webui.app.helpers.form_validations import ValidPath


class DeleteForm(Form):
    '''delete files form'''

    paths = FieldList(StringField('Paths', [InputRequired(), ValidPath()]),
                      min_entries=1)

    trash = BooleanField('In Trash', default=False)
