'''ldb.webui.app.forms.fields.empty_integer_field'''

from wtforms.fields import IntegerField


class EmptyIntegerField(IntegerField):
    '''Integer field that provides an empty string as its value instead of
    None constant
    '''

    def post_validate(self, form, validation_stopped):
        """
        Override if you need to run any field-level validation tasks after
        normal validation. This shouldn't be needed in most cases.

        :param form: The form the field belongs to.
        :param validation_stopped:
            `True` if any validator raised StopValidation.
        """
        if self.data is None and validation_stopped:
            self.data = ''
