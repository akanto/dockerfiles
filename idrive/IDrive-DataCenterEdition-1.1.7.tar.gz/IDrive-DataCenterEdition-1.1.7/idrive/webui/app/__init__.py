'''App package'''

import flask
import os

import idrive as ldb

from idrive import webui

_template_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                             'views')
_static_dir = os.path.join(
    os.path.dirname(os.path.dirname(os.path.realpath(__file__))), 'static')

app = flask.Flask('app', template_folder=_template_dir,
                  static_folder=_static_dir)

# session secret key
app.config['SECRET_KEY'] = 'random' if webui.DEBUG else os.urandom(24)

# cookie name
app.config['SESSION_COOKIE_NAME'] = '{}_session'.format(ldb.SHORT_NAME)

# turn on debug
app.debug = webui.DEBUG

# jinja
from idrive.webui.app.config.jinja import filters
from idrive.webui.app.config.jinja import extensions

# routes
from idrive.webui.app.config import routes
