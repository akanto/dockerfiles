'''Changeset model'''

import os

from idrive.core.data_types.dir_entry import DirEntry
from idrive.webui.app.models import list_files, backup_restore_set


def calculate(key, is_add, is_local, set_type, update_list):
    '''Generates the actual changeset given the paths to update and action

    @param key: session key
    @param is_add: is it an "add" operation?
    @param is_local: does it pertains to local files?
    @param set_type: backup set or restore set
    @param update_list: list of dir entries
    '''
    set_list = backup_restore_set.get(key, set_type)
    to_add = []
    to_remove = []
    if is_add:
        to_add, to_remove = calculate_add(set_list.dir_entry_set, update_list)
    else:
        to_add, to_remove = calculate_remove(key, is_local,
                                             set_list.dir_entry_set,
                                             update_list)

    if not to_add and not to_remove:
        message = ''

        if len(update_list) == 1:
            message = u'"{}" is '.format(os.path.basename(update_list[0].name))
        else:
            message = u'These items are '

        if is_add:
            message += u'already part of your'
        else:
            message += u'not in your'

        set_name = u'backup' if is_local else u'restore'
        message = u'{intro} {name} set'.format(intro=message, name=set_name)
        raise ValueError(message)

    return list(to_add), list(to_remove)


def calculate_add(set_list, update_list):
    '''Generate the changeset when desiring to add paths to the set

    @param set_list: list of dir entries that are in the set currently
    @param update_list: list of dir entries to add to the set

    @raise ValueError: if adding a non DirEntry
    '''

    # don't allow non DirEntries
    for update_entry in update_list:
        if not isinstance(update_entry, DirEntry):
            raise ValueError('Cannot add non DirEntry')

    to_add = set()
    to_remove = set()

    # empty set, all files should be added
    if not set_list:
        return set(update_list), to_remove

    for update_entry in update_list:

        ok = True
        add_candidates = set()
        remove_candidates = set()

        for set_entry in set_list:

            # update path is parent of existing set member
            if set_entry.name.startswith(update_entry.name + os.sep):

                remove_candidates.add(set_entry)
                add_candidates.add(update_entry)

            # as long as the update path and set path aren't equal and
            # update path isn't a child of an existing path, add to the set
            elif (update_entry != set_entry and not
                  update_entry.name.startswith(set_entry.name + os.sep)):

                add_candidates.add(update_entry)

            # adding a different version of the file triggers a remove
            # and add of the file
            elif (update_entry.isfile and
                  update_entry == set_entry and
                  hasattr(update_entry, 'version') and
                  hasattr(set_entry, 'version') and
                  update_entry.version != set_entry.version):

                remove_candidates.add(set_entry)
                add_candidates.add(update_entry)

            # it didn't pass one of the criteria, nothing should be done
            else:
                ok = False
                break

        if ok:
            to_add.update(add_candidates)
            to_remove.update(remove_candidates)

    return to_add, to_remove


def calculate_remove(key, is_local, set_list, update_list):
    '''Generate the changeset when desiring to remove paths from the set

    @param key: session key
    @param is_local: does it pertain to the local file list?
    @param set_list: list of dir entries that are currently in the set
    @param update_list: list of dir entries or strings to remove from the set
    '''

    to_add = set()
    to_remove = set()

    for set_entry in set_list:
        for update_entry in update_list:
            update_path = _get_update_path(update_entry)

            # update path is in the set, remove it
            if set_entry.name == update_path:
                to_remove.add(update_entry)

            # child paths of the update path in the set get removed
            elif set_entry.name.startswith(update_path + os.sep):
                to_remove.add(set_entry)

            # removing one child from a parent
            elif update_path.startswith(set_entry.name + os.sep):
                to_remove.add(set_entry)
                sibling_paths = _get_sibling_paths(update_path, update_list)
                to_add = to_add.union(_get_siblings_to_add(key, is_local,
                                                           sibling_paths,
                                                           set_entry.name))

    return to_add, to_remove


def _get_update_path(update_entry):
    '''Get the actual path for update operations

    @return the actual path
    '''
    if isinstance(update_entry, DirEntry):
        return update_entry.name

    return update_entry


def _get_siblings_to_add(key, is_local, excluded_files, stop_path):
    '''Recursively traverse the file tree up to the stop path adding all
    siblings except those listed

    @param key: session key
    @param is_local: does it pertain to the local file list?
    @param excluded_files: list of paths to not add in the sibling list
    @param stop_path: stop traversing up the file tree when we reach this path
    '''
    if isinstance(excluded_files, basestring):
        excluded_files = [excluded_files]

    file_lister = getattr(list_files, 'local' if is_local else 'remote')
    parent_path = os.path.dirname(excluded_files[0])
    files = file_lister(key, parent_path)
    to_add = []

    for file_ in files:
        if file_.name not in excluded_files:
            to_add.append(file_)

    if parent_path != stop_path:
        to_add = to_add + _get_siblings_to_add(key, is_local, parent_path,
                                               stop_path)
    return to_add


def _get_sibling_paths(path, entries):
    '''Returns all siblings of the given item (including the item)

    @param path: the reference path
    @param entries: all potential dir entries to consider
    '''
    parent_path = os.path.dirname(path)
    return [entry.name for entry in entries
            if os.path.dirname(_get_update_path(entry)) == parent_path]
