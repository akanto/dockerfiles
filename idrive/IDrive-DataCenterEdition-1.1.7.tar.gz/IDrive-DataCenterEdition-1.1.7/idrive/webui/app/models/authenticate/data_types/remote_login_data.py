"""Encapsulates remote login data"""


class RemoteLoginData(object):
    """Encapsulates remote login information"""

    def __init__(self):
        """Constructor."""

        self._username = None
        self._password = None
        self._pvtkey = None

    @property
    def username(self):
        return self._username

    @username.setter
    def username(self, value):
        self._username = value

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, value):
        self._password = value

    @property
    def pvtkey(self):
        return self._pvtkey

    @pvtkey.setter
    def pvtkey(self, value):
        self._pvtkey = value
