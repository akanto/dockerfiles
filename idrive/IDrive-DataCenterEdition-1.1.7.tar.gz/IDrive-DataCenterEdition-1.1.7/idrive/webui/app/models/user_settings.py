"""Model to get/set UserSettings"""

import idrive.proxy.interface as p_interface

from idrive.webui.app.models.authenticate.data_types import RemoteLoginData, \
    SysLoginData
from idrive.webui.core.models import PersistentObjManager

POM = PersistentObjManager()

_KEY = 'user_settings'

_USR_SETTINGS = 'user_settings'
_USR_SETTING_UPDATE_LOCAL = 'update_local'
_USR_SETTING_UPDATE_REMOTE = 'update_remote'


def get(key, refresh=False):
    """Retrieves UserSettings for current local user.

    @param refresh: If True, settings will be retrieved from disk. Otherwise
        it will retrieve it from the pom
    """
    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    try:
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
        remote_username = remote_login_data.username
    except KeyError:
        remote_username = None

    try:
        settings = POM.get(key, _KEY)
    except KeyError:
        refresh = True

    if refresh:
        username = sys_login_data.username
        password = sys_login_data.password

        settings = p_interface.passthru(username, password, _USR_SETTINGS,
                                        {'init_params': (remote_username,)})

        if isinstance(settings, ValueError):
            raise settings
        elif isinstance(settings, Exception):
            raise RuntimeError(str(settings))

        POM.set(key, _KEY, settings)

    return settings


def _update(key, section, name, value, method, remote_username):
    '''
    Updates UserSettings to set 'value' for 'name' under 'section'
    '''
    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    username = sys_login_data.username
    password = sys_login_data.password

    result = p_interface.passthru(username, password, _USR_SETTINGS,
                                  {'init_params': (remote_username,),
                                   'method': method,
                                   'params': (section, name, value)})

    if isinstance(result, ValueError):
        raise ValueError(str(result))
    elif isinstance(result, Exception):
        raise RuntimeError(str(result))

    POM.set(key, _KEY, result)

    return result


def update_local(key, section, name, value):
    '''
    Updates UserSettings to set 'value' for 'name' under 'section'
    '''
    try:
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
        remote_username = remote_login_data.username
    except KeyError:
        remote_username = None

    return _update(key, section, name, value, _USR_SETTING_UPDATE_LOCAL,
                   remote_username)


def update_remote(key, section, name, value):
    '''
    Updates UserSettings to set 'value' for 'name' under 'section'
    '''
    try:
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'RemoteLoginData' not set")

    return _update(key, section, name, value, _USR_SETTING_UPDATE_REMOTE,
                   remote_login_data.username)
