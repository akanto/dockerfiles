
import logging
import os
import platform
import pwd
import signal
import time

from daemon.daemon import DaemonContext
from daemon.pidfile import TimeoutPIDLockFile
from lockfile import AlreadyLocked, LockFailed, NotLocked

from idrive import SHORT_NAME
from idrive.conf.settings import GlobalSettings
from idrive.utils import log, ssl_utils
from idrive.webui.app import app

_LOG_FILE_NAME = '{}_webapp.log'.format(SHORT_NAME)
_PID_FILE = '/var/run/{}/webapp.pid'.format(SHORT_NAME)
_WEBAPP_LOGGER_NAME = "IBL Webapp"  # Only used for startup shutdown logs
_CHECK_PID_TIME = 0.5  # Timeout before checking web server process is dead
_CHECK_PID_RETRY_COUNT = 3  # How many times to check

_LOG_FORMAT = '%(asctime)s %(name)s: %(message)s'
_TIME_FORMAT = '%c'

_G = GlobalSettings()


def _setup_ssl_context():
    """Internal function to create a self signed SSL certificate
    and context for https connections
    """
    server_cert_file = _G.WEBAPP.server_cert_file
    server_key_file = _G.WEBAPP.server_key_file

    if (not os.path.exists(server_cert_file) or
            not os.path.exists(server_key_file)):
        server_cert_file = os.path.join(_G.APPLICATION.config_path,
                                        server_cert_file)
        server_key_file = os.path.join(_G.APPLICATION.config_path,
                                       server_key_file)

        hostname = platform.node().split('.')[0]

        # ".crt" and ".key" is automatically added
        ssl_utils.make_ssl_cert(server_cert_file.rpartition('.')[0],
                                host=hostname)

        _G.update_config('WEBAPP', 'server_cert_file', server_cert_file)
        _G.update_config('WEBAPP', 'server_key_file', server_key_file)

    return ssl_utils.make_context(server_cert_file, server_key_file)


def _start_web_server(host, port, ssl_context):
    """Internal function which actually starts the web server."""

    # Remove any existing log handler from flask and add our own
    for log_handler in app.logger.handlers:
        app.logger.removeHandler(log_handler)

    # setup log handler
    log_file = os.path.join(_G.LOGS.path, _LOG_FILE_NAME)
    max_size = int(_G.LOGS.max_size)
    max_files = int(_G.LOGS.max_log_files)
    log_handler = logging.handlers.RotatingFileHandler(log_file,
                                                       maxBytes=max_size,
                                                       backupCount=max_files)
    formatter = logging.Formatter(_LOG_FORMAT, _TIME_FORMAT)
    log_handler.setFormatter(formatter)

    # log level
    loglevel = logging.getLevelName(_G.LOGS.loglevel)
    if isinstance(loglevel, str):
        loglevel = logging.WARN
    log_handler.setLevel(loglevel)

    app.logger.name = _WEBAPP_LOGGER_NAME
    app.logger.addHandler(log_handler)

    # For other libraries which use utils.log interface, init utils.log also
    log.init(_WEBAPP_LOGGER_NAME, log_handler)

    try:
        user = _G.WEBAPP.user
    except (AttributeError, ValueError):
        user = 'nobody'

    os.setgid(pwd.getpwnam(user).pw_gid)
    os.setuid(pwd.getpwnam(user).pw_uid)

    app.logger.info("Starting web server at {}:{}".format(host, port))

    # TODO - May move to a standalone WSGI server here instead of using
    # werkzeug built in one
    app.run(host, port, ssl_context=ssl_context)


def start():
    """Starts the web server.

    If app is configured in debug mode, this just runs in command line
    and exits.
    """
    try:
        host = _G.WEBAPP.host
    except AttributeError:
        app.logger.warning("Could not get web server host from conf")
        app.logger.warning("Starting with default 'localhost'")
        host = 'localhost'

    try:
        port = int(_G.WEBAPP.port)
    except (AttributeError, ValueError):
        app.logger.warning("Could not get web server port from conf")
        app.logger.warning("Staring with default port '56000'")
        port = 56000

    if app.debug:
        app.run(host, port)
        return

    if os.getuid() != 0:
        raise OSError("Web server must be started by super user")

    # NOTE: Don't init utils.log here

    try:
        user = _G.WEBAPP.user
    except (AttributeError, ValueError):
        user = 'nobody'

    pid_file_path = os.path.dirname(_PID_FILE)
    if not os.path.exists(pid_file_path):
        os.makedirs(pid_file_path, 0700)

    if pid_file_path != '/var/run':
        # This is required so that web server running as nobody can
        #   delete the pid file when exiting.
        os.chown(pid_file_path,
                 pwd.getpwnam(user).pw_uid,
                 pwd.getpwnam(user).pw_gid)

    # Check if any instance already running
    pidfile = TimeoutPIDLockFile(_PID_FILE, -0.001)
    if pidfile.is_locked():
        pid = pidfile.read_pid()
        try:
            os.kill(pid, 0)
        except OSError:
            pidfile.break_lock()
        else:
            raise RuntimeError("Web server already running with pid {}"
                               .format(pid))

    # web server logs are different from application.log
    log_file_path = _G.LOGS.path + _LOG_FILE_NAME
    log_file = open(log_file_path, 'a')

    # webapp.log needs to be 'nobody' writable
    os.chown(log_file_path,
             pwd.getpwnam(user).pw_uid,
             pwd.getpwnam(user).pw_gid)

    # SSL context must be setup as root
    ssl_context = _setup_ssl_context()

    context = DaemonContext(pidfile=pidfile, stdout=log_file, stderr=log_file)

    try:
        with context:
            _start_web_server(host, port, ssl_context)
    except AlreadyLocked as err:
        log.warning("Web server is already running")
    except (LockFailed, NotLocked) as err:
        log.error("Could not acquire lock to start web server : {}"
                  .format(err))
    finally:
        log.info("Web server shutting down")


def stop():
    """Stop the web server."""

    if os.getuid() != 0:
        raise OSError("Web server must be stopped by super user")

    pidfile = TimeoutPIDLockFile(_PID_FILE, -0.001)
    if pidfile.is_locked():
        pid = pidfile.read_pid()
        try:
            os.kill(pid, signal.SIGINT)
        except OSError:
            pidfile.break_lock()
        else:
            # Check 3 times if process died or not
            for _ in range(0, _CHECK_PID_RETRY_COUNT + 1):
                time.sleep(_CHECK_PID_TIME)
                try:
                    # check if process died or not, if not kill again
                    os.kill(pid, 0)
                except OSError:
                    # exception means process is not alive any more
                    break
                else:
                    # else process is alive
                    os.kill(pid, signal.SIGKILL)
            else:
                raise OSError("Could not stop web server even after 3 retries")

            pidfile.break_lock()
    else:
        raise RuntimeError("Web server is not running")


def status():
    """Check if web server is running"""

    pid = None
    pidfile = TimeoutPIDLockFile(_PID_FILE, -0.001)
    if pidfile.is_locked():
        pid = pidfile.read_pid()

    return pid
