"""
Backup/Restore set info
"""

import os
import cPickle as pickle

from pickle import PickleError, PicklingError, UnpicklingError

from idrive.conf.settings import UserSettings
from idrive.core.data_types import DirEntry


class BackupRestoreSet(object):
    """Backup/Restore set info."""

    BACKUP_SET = 'backup_set'
    RESTORE_SET = 'restore_set'

    def __init__(self, username, set_type, path='/'):
        """Encapsulates a Backup/Restore set."""

        self._BACKUP_RESTORE_SET_FILE = None

        if set_type not in (self.BACKUP_SET, self.RESTORE_SET):
            raise ValueError('Invalid Parameters')

        backup_restore_set_dir = UserSettings(username).BR_SET.path

        if not os.path.exists(backup_restore_set_dir):
            os.makedirs(backup_restore_set_dir, mode=0700)

        self._BACKUP_RESTORE_SET_FILE = \
            os.path.normpath(os.path.join(backup_restore_set_dir, set_type))

        if os.path.exists(self._BACKUP_RESTORE_SET_FILE):
            try:
                with open(self._BACKUP_RESTORE_SET_FILE, 'rb') as f:
                    stored_backup_restore_set = pickle.load(f)
            except (OSError, PickleError, PicklingError) as err:
                raise OSError(err)
            else:
                self.__dict__.update(stored_backup_restore_set.__dict__)
        else:
            self.dir_entry_set = set()
            self.path = path
            self._sync()

    def add(self, dir_entry):
        """Add files/folder to backup/restore set."""

        self.dir_entry_set.add(dir_entry)
        self._sync()

    def remove(self, item):
        """Remove files/folder from backup/restore set.

        @param {DirEntry|int|string} item: item to remove
        """

        if isinstance(item, basestring):
            for index, entry in enumerate(self.dir_entry_set):
                if entry.name == item:
                    item = index
                    break

        # Ideally backup set would be small. So the following
        # operation of converting from set to list, then back
        # to set should not take much time
        # TODO - make sure this conversion doesn't change the
        # index. set() is not ordered, so the index may not
        # point to the correct index
        if isinstance(item, int):
            self.dir_entry_set = list(self.dir_entry_set)
            del self.dir_entry_set[item]
            self.dir_entry_set = set(self.dir_entry_set)
            self._sync()
        elif isinstance(item, DirEntry):
            self.dir_entry_set.remove(item)
            self._sync()

    def setpath(self, path):
        self.path = path
        self._sync()

    def _sync(self):
        """Serialize Backup/Restore set and store on disk."""

        try:
            with open(self._BACKUP_RESTORE_SET_FILE, 'wb') as f:
                pickle.dump(self, f)

        except(IOError, PickleError, UnpicklingError) as err:
            raise IOError(err)

    def get(self):
        """Returns the backup/restore set and path.

        The set() is converted into list before returning.

        """

        return list(self.dir_entry_set), self.path
