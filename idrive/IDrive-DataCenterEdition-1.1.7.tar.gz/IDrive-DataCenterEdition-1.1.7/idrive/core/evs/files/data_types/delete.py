
from idrive.core.evs.files.data_types.exceptions import DeleteError
import re
from idrive.core.evs.idevsutil.data_types import EVSResponse


class DeleteResult(object):
    """ Encapsulates delete result.

    """

    def __init__(self, xml_string):
        """Constructor."""

        xml_string = re.sub('>[^<]*<', '>\n<', xml_string.strip(),
                            flags=re.DOTALL)

        self.result = []
        deleted_items_count = 0
        tot_items_deleted = 0

        for xml_line in xml_string.split('\n'):
            xml = EVSResponse(xml_line).xml

            if xml is None:
                raise DeleteError("Invalid response from EVS : {}"
                                  .format(xml_string))

            if xml.tag == 'item':
                # success response
                if 'op' in xml.attrib:
                    if xml.get('op') != 'deleted' or 'fname' not in xml.attrib:
                        raise DeleteError("Invalid response from EVS : {}"
                                          .format(xml_string))

                    self.result.append({'name': xml.get('fname'),
                                        'success': True})
                    deleted_items_count += 1

                if 'tot_items_deleted' in xml.attrib:
                    try:
                        tot_items_deleted = int(xml.get('tot_items_deleted'))
                    except ValueError:
                        tot_items_deleted = -1

            if xml.tag == 'tree':
                # error response
                if ('path' not in xml.attrib or 'message' not in xml.attrib
                        or xml.get('message') != 'ERROR'):

                    raise DeleteError("Invalid response from EVS : {}"
                                      .format(xml_string))

                self.result.append({'name': xml.get('path'),
                                    'success': False})

        if len(self.result) == 0 or tot_items_deleted != deleted_items_count:
            raise DeleteError("Invalid response from EVS : {}"
                              .format(xml_string))
