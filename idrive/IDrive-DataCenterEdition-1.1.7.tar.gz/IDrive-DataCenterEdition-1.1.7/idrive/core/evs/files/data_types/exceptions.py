"""files related exceptions"""

from idrive.core.evs.idevsutil.data_types import EVSError, EVSInvalidPathError, \
    EVSAccountUnderMaintenanceError, EVSCommunicationError

# Definition for ListingError is also used in core.local
# So it was moved to the top level data_types
from idrive.core.data_types.exceptions import ListingError


class FileVersionInfoError(EVSError):
    """File Version related error"""
    pass


class FileVersionInfoLoginError(FileVersionInfoError):
    """Specializes invalid uername/password"""
    pass


class FileVersionInfoInvalidPathError(FileVersionInfoError,
                                      EVSInvalidPathError):
    """Specializes invalid path error"""
    pass


class SearchError(EVSError):
    """Search related error"""
    pass


class SearchLoginError(SearchError):
    """Specalizes invalid username/password error"""
    pass


class SearchAccountUnderMaintenanceError(SearchError,
                                         EVSAccountUnderMaintenanceError):
    """Specalizes invalid username/password error"""
    pass


class SearchCommunicationError(SearchError,
                               EVSCommunicationError):
    """Network error"""
    pass


class PropertiesError(EVSError):
    """Properties related error"""
    pass


class PropertiesLoginError(PropertiesError):
    """Specializes invalid username/password error"""
    pass


class PropertiesInvalidPathError(PropertiesError, EVSInvalidPathError):
    """Specializes invalid path error"""
    pass


class DeleteError(EVSError):
    """Delete related errors"""
    pass


class DeleteLoginError(DeleteError):
    """Specializes invalid username/password error"""
    pass


class RestoreError(EVSError):
    """Restore related errors"""
    pass


class RestoreLoginError(RestoreError):
    """Specializes invalid username/password error"""
    pass


class RenameError(EVSError):
    """Rename related errors"""
    pass


class RenameLoginError(RenameError):
    """Specializes invalid username/password error"""
    pass


class RenameInvalidPathError(RenameError, EVSInvalidPathError):
    """Specializes invalid path error"""
    pass


class UploadDownloadError(EVSError):
    """Base class for upload/download Error"""


class UploadError(UploadDownloadError):
    """Upload related errors"""
    pass


class UploadLoginError(UploadError):
    """Specializes invalid username/password error"""
    pass


class UploadInvalidPathError(UploadError, EVSInvalidPathError):
    """Specializes invalid path error"""
    pass


class UploadAccountUnderMaintenanceError(UploadError,
                                         EVSAccountUnderMaintenanceError):
    """Specializes 'Account is under maintenance' error"""
    pass


class UploadCancelledError(UploadError):
    """Upload Cancelled"""
    pass


class UploadCommunicationError(UploadError,
                               EVSCommunicationError):
    """Network error"""
    pass


class DownloadError(UploadDownloadError):
    """Upload related errors"""
    pass


class DownloadLoginError(DownloadError):
    """Specializes invalid username/password error"""
    pass


class DownloadInvalidPathError(DownloadError, EVSInvalidPathError):
    """Specializes invalid path error"""
    pass


class DownloadAccountUnderMaintenanceError(DownloadError,
                                           EVSAccountUnderMaintenanceError):
    """Specializes 'Account is under maintenance' error"""
    pass


class DownloadCancelledError(DownloadError):
    """Download Cancelled"""
    pass


class DownloadCommunicationError(DownloadError,
                                 EVSCommunicationError):
    """Network error"""
    pass


class ListingLoginError(ListingError, EVSError):
    """Specializes invalid username/password for remote listing only"""
    pass


class ListingInvalidPathError(ListingError, EVSInvalidPathError):
    """Specializes invalid path error only for remote listing"""
    pass
