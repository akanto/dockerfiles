"""Get version info of a particular file."""

import sys

from idrive.core.evs.idevsutil import execute_command, VERSION
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, EVSError, \
    EVSInvalidServerError, EVSLoginError, EVSInvalidPathError
from idrive.core.evs.account import get_server_address, ServerAddressError, \
    ServerAddressLoginError
from idrive.core.evs.files.data_types import FileVersionInfo
from idrive.core.evs.files.data_types.exceptions import FileVersionInfoError,\
    FileVersionInfoLoginError, FileVersionInfoInvalidPathError


def get_version_info(username, password, path):
    """Get version info of a particular file."""

    # retry with cached=False for EVSInvalidServerError
    for cached in [True, False]:
        try:
            server_address = get_server_address(username, password, cached)
        except ServerAddressLoginError as err:
            raise FileVersionInfoLoginError(err)
        except ServerAddressError as err:
            _, _, tb = sys.exc_info()
            raise FileVersionInfoError(err), None, tb

        try:
            ipaddress = server_address.CLU_SERVER_IP
            succ_xml, err_xml = execute_command(VERSION,
                                                username, password,
                                                server_address=ipaddress,
                                                remote_path=path)

            if err_xml:
                raise EVSErrorFactory.get_error(err_xml)

        except EVSLoginError as err:
            raise FileVersionInfoLoginError(err)
        except EVSInvalidPathError as err:
            raise FileVersionInfoInvalidPathError(err)
        except EVSInvalidServerError as err:
            if cached:
                continue
            else:
                raise FileVersionInfoError(err)
        except EVSError as err:
            _, _, tb = sys.exc_info()
            raise FileVersionInfoError(err), None, tb
        else:
            break

    return FileVersionInfo(succ_xml)


if __name__ == '__main__':
    import cPickle as pickle
    from idrive.utils.command_line import process_command_line

    kwargs = process_command_line({'username', 'password', 'path'})

    try:
        file_version_info = get_version_info(**kwargs)
    except FileVersionInfoError as err:
        sys.stderr.write(pickle.dumps(err))
        sys.exit(1)
    else:
        print pickle.dumps(file_version_info)
        sys.exit(0)
