"""Restore file/folder in EVS."""

from idrive.core.evs.files.private.delete_restore import do_operation, \
    do_operation_ci
from idrive.core.evs.idevsutil import RESTORE


def restore(username, password, file_list, pvtkey=None):
    """Restore deleted file/folder from EVS.

    @param username: EVS username
    @param password: EVS password
    @param file_list: list of file/folder path to restore.
    @param pvtkey: Private key. Optional.

    @return: RestoreResult, even if remote restore failed for any file.

    @raise RestoreLoginError: Invalid username/password
    @raise RestoreError: All other error except remote restore error, which
    will be reported in RestoreResult itself.
    """

    # Common code for both restore/delete is defined in delete_restore
    # module. From here we only call do_operation with proper operation type
    return do_operation(RESTORE, username, password, file_list, pvtkey)

if __name__ == '__main__':
    do_operation_ci(RESTORE)
