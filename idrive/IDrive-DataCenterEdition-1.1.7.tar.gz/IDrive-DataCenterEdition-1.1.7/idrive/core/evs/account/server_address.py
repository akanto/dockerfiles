"""EVS server address for any user."""

import sys
import os
import pwd

from pickle import PickleError, PicklingError, UnpicklingError
import cPickle as pickle

from idrive.core.evs.idevsutil import execute_command, GET_ADDRESS
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, EVSLoginError,\
    EVSError

import idrive.utils.validations as validations
from idrive.core.evs.account.data_types import ServerAddress, ServerAddressError,\
    ServerAddressLoginError

from idrive import SHORT_NAME

#       Also need to create a centralized method to verify cached file path
_FILE_NAME = 'server_address'


def _get_cached_server_address_path(remote_username):
    """Calculates and returns where the cached serve address is to be stored

    """

    home_dir = pwd.getpwuid(os.geteuid()).pw_dir

    return os.path.join(home_dir, '.{}'.format(SHORT_NAME), remote_username)


def get_server_address(username, password, cached=False):
    """Return the EVS server details for any user

    @param username: EVS username
    @param password: EVS password
    @param cached: By Default, it returns back the cached value unless
    specified otherwise. It stores the ServerAddress object in serialized
    format in a file. If fetching cached value fails, it falls back to
    get value from EVS and writes the output to the cached file.

    @return: Instance of ServerAddress class

    @raise ServerAddressLoginError: Invalid username/password
    @raise ServerAddressError: All other error

    """

    if cached:
        try:
            succ_obj = get_cached_server_address(username)
            return succ_obj
        except(IOError) as err:
            pass

    try:
        succ_xml, err_xml = execute_command(GET_ADDRESS, username, password)

        if err_xml:
            raise EVSErrorFactory.get_error(err_xml)

        succ_obj = ServerAddress(succ_xml)

        try:
            write_cached_server_address(username, succ_obj)
        except(IOError) as err:
            pass

    except (EVSLoginError) as err:
        raise ServerAddressLoginError(err)
    except (EVSError) as err:
        _, _, tb = sys.exc_info()
        raise ServerAddressError(err), None, tb

    return succ_obj


def get_cached_server_address(username):
    """Return cached server address object from file.

    @param username: EVS username

    @return: Instance of ServerAddress class

    @raise IOError: If address cannot be loaded from cache

    """

    try:
        cache_file_path = _get_cached_server_address_path(username)

        if not validations.valid_path(cache_file_path):
            raise ValueError("Invalid value passed for username")

        address_file = cache_file_path + os.path.sep + _FILE_NAME

        with open(address_file, 'r') as f:
            obj = pickle.load(f)
            f.close()
        return obj
    except(IOError, PickleError, PicklingError, ImportError) as err:
        _, _, tb = sys.exc_info()
        raise IOError(err), None, tb


def write_cached_server_address(username, obj):
    """Write server address object for user in file.

    @param username: EVS username
    @param obj: Instance of ServerAddress class

    @raise IOError: If obj cannot be saved to cache

    """

    try:
        cache_file_path = _get_cached_server_address_path(username)

        if not validations.valid_path(cache_file_path):
            raise ValueError("Invalid value passed for username")

        address_file = cache_file_path + os.path.sep + _FILE_NAME

        if not os.path.exists(cache_file_path):
            os.makedirs(cache_file_path, mode=0700)

        with open(address_file, 'w') as f:
            pickle.dump(obj, f)

    except(IOError, PickleError, UnpicklingError) as err:
        _, _, tb = sys.exc_info()
        raise IOError(err), None, tb


if __name__ == '__main__':
    from idrive.utils.command_line import process_command_line

    # By Default, cached is set as True
    kwargs = process_command_line({'username', 'password'},
                                  {'no-cached'})

    if 'no_cached' in kwargs:
        kwargs['cached'] = not kwargs['no_cached']
        del kwargs['no_cached']

    try:
        server_address = get_server_address(**kwargs)
    except (ValueError, ServerAddressError) as err:
        sys.stderr.write(pickle.dumps(err))
        sys.exit(1)

    print pickle.dumps(server_address)
    sys.exit(0)
