'''Common bin utilities & methods'''

import re
import socket

from multiprocessing.connection import Listener

# messages
_HOST_INVALID = 'Please enter "localhost" or a valid IP address'
_HOST_INVALID_INTERFACE = 'Please choose an IP address in use by your system'
_PORT_INVALID_RANGE = 'Please enter a port number between 5000 and 65,535'
_PORT_IN_USE = 'Port "{}" already used by another process'


def valid_host(host):
    '''Check if host is a valid ip address or hostname'''
    try:
        if not re.match(r'^(|localhost|\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$',
                        host):
            raise ValueError()
        # try to create a socket for this address
        tempsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        tempsocket.bind((host, 0))
        tempsocket.close()
    except socket.error:
        raise ValueError(_HOST_INVALID_INTERFACE)
    except (ValueError, TypeError):
        raise ValueError(_HOST_INVALID)


def valid_port(port, settings):
    '''Check if port number is valid and has not been used'''
    if port == '':
        return

    try:
        port = int(port)
    except ValueError:
        raise ValueError(_PORT_INVALID_RANGE)

    if port < 5000 or port > 65535:
        raise ValueError(_PORT_INVALID_RANGE)
    elif str(port) in settings.values():
        raise ValueError(_PORT_IN_USE.format(port))
    else:
        try:
            Listener(('0.0.0.0', port)).close()
        except socket.error:
            raise ValueError(_PORT_IN_USE.format(port))
