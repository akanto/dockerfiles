"""Utility module to dynamically import a module given the path"""

import sys
import imp


def _load_module(partname, parent=None):
    """Internal function which loads one module"""

    full_name = partname
    try:
        return sys.modules[full_name]
    except KeyError:
        pass

    path = None
    if parent is not None:
        full_name = "{}.{}".format(parent.__name__, partname)
        try:
            path = parent.__path__
        except AttributeError:
            raise ImportError('No module named {}'.format(partname))

    fp, pathname, stuff = imp.find_module(partname, path)

    try:
        loaded_module = imp.load_module(full_name, fp, pathname, stuff)
    finally:
        if fp:
            fp.close()

    if parent is not None:
        setattr(parent, partname, loaded_module)

    return loaded_module


def import_module(name):
    """Import a module and return the module object."""

    if '.' in name:
        i = name.find('.')
        head, tail = name[0:i], name[i + 1:]
    else:
        head = name
        tail = ''

    parent = None
    while tail:
        parent = _load_module(head, parent)
        i = tail.find('.')
        i = len(tail) if i < 0 else i
        head, tail = tail[:i], tail[i + 1:]

    return _load_module(head, parent)
