"""Format size in human readable way."""

import re
from jinja2.filters import do_filesizeformat


def size_format(num):
    '''Wrapper function for jinja2's excellent file formatting function'''
    size = do_filesizeformat(num, True).split()
    # 512.0 -> 512
    size[0] = re.sub(r'\.0+$', '', size[0])
    # we are using binary file sizing but we don't like the wording:
    # GiB -> GB
    size[1] = size[1].replace('i', '')
    return ' '.join(size)
