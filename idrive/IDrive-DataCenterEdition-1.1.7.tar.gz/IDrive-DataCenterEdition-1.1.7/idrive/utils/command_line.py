"""Common module used for processing command line args."""

import argparse


def process_command_line(required_arg_names={}, optional_arg_names={}):
    """Processes command line arguments.

    required_arg_names are argument names which are mandatory.
    optional_arg_names are optional names.

    e.g required_arg_name = {'username', 'password'} means
    --username and --password are mandatory

    optional_arg_names can be separated by a . to set the action
    that would be taken for that argument. If nothing is provided,
    True is set when the argument is passed.

    e.g. optional_arg_name={'path.store./'} means
    --path is optional. If passed, it will get the value passed, otherwise,
    default value of /

    e.g. optional_arg_name={'pvtkey.store'} means
    --pvtkey is optional. If passed, it will get the value passed, otherwise,
    it will not get anything, since default value is not set.

    e.g. optional_arg_name={'incremental'} means
    --incremental is optional. If passed, incremental will be set as
    true, nothing will be set otherwise.

    returns a dict of keyword arguments which can be directly used
    in function calls.

    """

    parser = argparse.ArgumentParser()

    # for arg_info in required_arg_names:
    #    arg_parts = arg_info.split('.')
    #    arg_name = arg_parts[0]
    #    arg_type = argparse.FileType('r') if len(arg_parts) > 1 else str
    #    parser.add_argument('--' + arg_name, type=arg_type, required=True)

    for arg_name in required_arg_names:
        if arg_name == 'file-list' or arg_name == 'dir-entry-list':
            parser.add_argument('--' + arg_name, type=argparse.FileType('rb'),
                                required=True)
        else:
            parser.add_argument('--' + arg_name, type=str, required=True)

    for arg_info in optional_arg_names:
        arg_parts = arg_info.split('.')
        arg_name = arg_parts[0]
        arg_action = arg_parts[1] if len(arg_parts) > 1 else 'store_true'
        arg_default = arg_parts[2] if len(arg_parts) > 2 else None

        if arg_default is None:
            parser.add_argument('--' + arg_name, action=arg_action)
        else:
            parser.add_argument('--' + arg_name, action=arg_action,
                                default=arg_default)

    args = parser.parse_args()
    if hasattr(args, 'file_list'):
        # convert files/folders path from file into list
        args.file_list = args.file_list.readlines()

    if hasattr(args, 'dir_entry_list'):
        import cPickle as pickle

        # convert files/folders dir entry from file into list
        args.dir_entry_list = pickle.load(args.dir_entry_list)

    return vars(args)
