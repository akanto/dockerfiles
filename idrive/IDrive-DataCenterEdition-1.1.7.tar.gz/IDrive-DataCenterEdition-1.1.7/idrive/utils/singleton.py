#@PydevCodeAnalysisIgnore
'''Utility Class to make other classes singleton.

This callable class can be used as a __metaclass__
to other classes for making those classes singleton.

'''


class MetaSingleton(type):
    '''metaclass for Singleton classes.

    Use only as a __metaclass__ to create singleton classes.
    Only for new style classes.

    '''

    def __call__(cls, *args, **kwargs):
        '''Callable

        This ensures one and only on instance of
        the class is created which uses MetaSingleton as its __metaclass__.
        An attribute, _my_instance, will be added to the class on
        first instantiation. _my_instance will store the class
        instantiation. Every instantiation after that
        will return the value stored in _my_instance.

        '''

        if not hasattr(cls, '_my_instance'):
            cls._my_instance = super(MetaSingleton, cls).__call__(*args,
                                                                  **kwargs)

        return cls._my_instance
