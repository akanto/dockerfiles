'''
Created on Nov 5, 2013

@author: gaurav
'''


class Bunch(object):
    '''A small do-nothing class to collect a bunch of stuff together'''
    def __init__(self, dict_):
        for key in dict_:
            setattr(self, key, dict_[key])

    def __repr__(self):
        """For pretty printing."""

        return str(self.__dict__)

    def __getitem__(self, index):
        """Subscript access"""

        try:
            item = getattr(self, index)
        except AttributeError:
            raise IndexError("{} not found".format(index))

        return item

    def __iter__(self):
        """Iterator."""

        return iter(self.__dict__)

    # that's it!  Now, you can create a Bunch
    # whenever you want to group a few variables
