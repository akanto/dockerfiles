"""Encapsulates a backup/restore job."""

from idrive.common.data_types.backup_restore_set import BackupRestoreSet
from idrive.common.data_types.login_data import LoginData


class BackupRestoreJob(object):
    """Encapsulates a backup/restore job.

    A backup/restore job consists of
    operation : <BACKUP | RESTORE>
    backup_restore_set : The backup or restore set
    login_data : EVS login data

    """

    BACKUP = 10
    RESTORE = 20

    def __init__(self, username, job_type):
        """Constructor."""

        if job_type not in [self.BACKUP, self.RESTORE]:
            raise ValueError("Invalid Job Type")

        self.login_data = LoginData().load(username)

        if job_type == self.BACKUP:
            set_type = BackupRestoreSet.BACKUP_SET
        else:
            set_type = BackupRestoreSet.RESTORE_SET
        self.backup_restore_set = BackupRestoreSet(username, set_type)
