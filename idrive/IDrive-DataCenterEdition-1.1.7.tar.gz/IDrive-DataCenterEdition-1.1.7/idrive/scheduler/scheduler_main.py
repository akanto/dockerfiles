"""Scheduler execution start here."""

import signal
import os
from time import sleep

from daemon.daemon import DaemonContext
from daemon.pidfile import TimeoutPIDLockFile
from lockfile import AlreadyLocked, LockFailed

import idrive.utils.log as log
import idrive.utils.server as server
from idrive.conf.settings import GlobalSettings

import idrive.scheduler.private.ap_scheduler as ap_scheduler
import idrive.scheduler.private.server_callbacks as server_callbacks

from idrive.scheduler import _AUTHKEY
from idrive import SHORT_NAME


_PID_FILE = '/var/run/{}/sched.pid'.format(SHORT_NAME)
_CHECK_PID_TIME = 0.5   # Timeout before checking scheduler process is dead
_CHECK_PID_RETRY_COUNT = 3  # How many times to check

_SCHEDULER_LOGGER_NAME = 'IBL Scheduler'

# global apscheduler object
_ap_scheduler = None


def _start_scheduler():
    """Starts the scheduler thread."""

    global _ap_scheduler

    _ap_scheduler = ap_scheduler.create()


def _start_listener():
    """This starts up the listener for receiving commands for the scheduler."""

    g = GlobalSettings()

    try:
        host = g.SCHEDULER.host
    except AttributeError:
        log.warning("Could not get scheduler server host from conf")
        log.warning("Starting with default 'localhost'")
        host = 'localhost'

    try:
        port = int(g.SCHEDULER.port)
    except (AttributeError, ValueError):
        log.warning("Could not get scheduler server port from conf")
        log.warning("Staring with default port '50000'")
        port = 50000

    log.info("Starting scheduler daemon at {}:{}".format(host, port))

    # Must set ap_scheduler in callback module for it to work properly
    server_callbacks.set_ap_scheduler(_ap_scheduler)
    server.start((host, port),
                 server_callbacks.server_callback,
                 _AUTHKEY)


def start():
    """Starts the scheduler and listener threads."""

    if os.getuid() != 0:
        raise OSError("Scheduler must be started by super user")

    log.init(_SCHEDULER_LOGGER_NAME)

    pid_file_path = os.path.dirname(_PID_FILE)
    if not os.path.exists(pid_file_path):
        os.makedirs(pid_file_path, 0700)

    pidfile = TimeoutPIDLockFile(_PID_FILE, -0.001)
    if pidfile.is_locked():
        pid = pidfile.read_pid()
        try:
            os.kill(pid, 0)
        except OSError:
            log.warning("Unclean shutdown of scheduler last time")
            pidfile.break_lock()
        else:
            raise RuntimeError("Scheduler daemon already running with pid {}"
                               .format(pid))

    log_fds = [x.stream.fileno() for x in log.get_handlers()]
    log_file = None
    if GlobalSettings().LOGS.loglevel == 'DEBUG':
        log_file = log.get_handlers()[0].stream

    context = DaemonContext(pidfile=pidfile,
                            files_preserve=log_fds,
                            stdout=log_file,
                            stderr=log_file)

    try:
        with context:
            _start_scheduler()
            _start_listener()
    except AlreadyLocked as err:
        log.info("Scheduler daemon is already running")
    except LockFailed as err:
        log.error("Could not acquire lock to start scheduler daemon : {}"
                  .format(err))
    finally:
        log.info("Scheduler daemon shutting down")


def stop():
    """Stop the daemon."""

    if os.getuid() != 0:
        raise OSError("Scheduler must be stopped by super user")

    pidfile = TimeoutPIDLockFile(_PID_FILE, -0.001)
    if pidfile.is_locked():
        pid = pidfile.read_pid()

        try:
            os.kill(pid, signal.SIGINT)
        except OSError:
            pidfile.break_lock()
        else:
            # Check 3 times if process died or not
            for _ in range(0, _CHECK_PID_RETRY_COUNT + 1):
                sleep(_CHECK_PID_TIME)
                try:
                    # check if process died or not, if not kill again
                    os.kill(pid, 0)
                except OSError:
                    # exception means process is not alive any more
                    break
                else:
                    # else process is alive
                    os.kill(pid, signal.SIGKILL)
            else:
                raise OSError("Could not stop scheduler even after 3 retries")

            pidfile.break_lock()
    else:
        raise RuntimeError("Scheduler daemon is not running")


def status():
    """Check if scheduler is running"""

    pid = None
    pidfile = TimeoutPIDLockFile(_PID_FILE, -0.001)
    if pidfile.is_locked():
        pid = pidfile.read_pid()

    return pid
