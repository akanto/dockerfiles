"""Callbacks for different apcheduler events."""

import pwd

import idrive.utils.log as log

from idrive.scheduler.data_types import JobSchedule
from idrive.scheduler.private.ap_scheduler import add_job, get_jobs, remove_job, \
    BACKUP_JOB, RESTORE_JOB
import idrive.scheduler.private.backup as backup
import idrive.scheduler.private.restore as restore

from . import ADD_JOB, REMOVE_JOB, GET_JOBS, GET_PROGRESS, CANCEL_JOB

_ap_scheduler = None


def set_ap_scheduler(ap_scheduler):
    """Set the apscheduler before any callbacks are registered."""

    global _ap_scheduler
    _ap_scheduler = ap_scheduler


def server_callback(callback_data=None):
    """Callback when some data is sent to server.


    This should return any value to be sent back to the client.

    """

    try:
        command, params = callback_data
    except (ValueError, TypeError):
        log.error("Insufficient data received", mod_name=__name__)
        return None

    if command not in [ADD_JOB, REMOVE_JOB, GET_JOBS,
                       GET_PROGRESS, CANCEL_JOB]:
        log.error("Invalid command from client : {}".format(command),
                  mod_name=__name__)
        raise ValueError("Invalid command")

    if command == ADD_JOB:
        try:
            job_type, for_user, as_user, job_schedule, retry_count = params
        except (ValueError, TypeError):
            log.error("Invalid parameters for ADD_JOB : {}"
                      .format(str(params)),
                      mod_name=__name__)
            raise ValueError("Invalid parameters")

        if not isinstance(job_schedule, JobSchedule):
            log.error("Invalid job_schedule : {}"
                      .format(str(job_schedule)),
                      mod_name=__name__)
            raise ValueError("Invalid job_schedule")

        if not isinstance(retry_count, int):
            raise ValueError("Invalid retry_count")

    if command in [REMOVE_JOB, GET_PROGRESS, CANCEL_JOB]:
        try:
            job_type, for_user, as_user = params
        except (ValueError, TypeError):
            log.error("Invalid parameters for "
                      "REMOVE_JOB|GET_PROGRESS|CANCEL_JOB : {}"
                      .format(str(params)),
                      mod_name=__name__)
            raise ValueError("Invalid parameters")

    if command == GET_JOBS:
        try:
            for_user, as_user = params
        except (ValueError, TypeError):
            log.error("Invalid parameters for REMOVE_JOB : {}"
                      .format(str(params)),
                      mod_name=__name__)
            raise ValueError("Invalid parameters")

    if command in [ADD_JOB, REMOVE_JOB, GET_PROGRESS, CANCEL_JOB]:
        if job_type not in [BACKUP_JOB, RESTORE_JOB]:
            log.error("Invalid job type for ADD_JOB : {}"
                      .format(str(job_type)),
                      mod_name=__name__)
            raise ValueError("Invalid job_type")

    for_user, as_user = str(for_user), str(as_user)
    try:
        pwd.getpwnam(as_user)
    except KeyError:
        log.error("No such user : {}".format(as_user), mod_name=__name__)
        raise ValueError("No such user")

    # Note: Don't return None for add/remove job in case of success.
    #  else it will be regarded as error
    return_data = True
    if command == ADD_JOB:
        add_job(_ap_scheduler, job_type, for_user, as_user, job_schedule,
                retry_count)

    elif command == REMOVE_JOB:
        remove_job(_ap_scheduler, job_type, for_user, as_user)

    elif command == GET_JOBS:
        return_data = get_jobs(_ap_scheduler, for_user, as_user)

    elif command == GET_PROGRESS:
        if job_type == BACKUP_JOB:
            return_data = backup.get_progress(for_user, as_user)
        elif job_type == RESTORE_JOB:
            return_data = restore.get_progress(for_user, as_user)
        else:
            raise ValueError("Invalid job_type '{}' for command '{}'"
                             .format(str(job_type), str(command)))
    elif command == CANCEL_JOB:
        if job_type == BACKUP_JOB:
            return_data = backup.cancel_job(for_user, as_user)
        elif job_type == RESTORE_JOB:
            return_data = restore.cancel_job(for_user, as_user)
        else:
            raise ValueError("Invalid job_type '{}' for command '{}'"
                             .format(str(job_type), str(command)))

    return return_data
