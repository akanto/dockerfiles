"""Runs backup for_user, as_user."""

import idrive.scheduler.private.backup_restore as backup_restore


# Note : Don't change this function signature after production move
#  or already scheduled jobs will fail
def run(for_user, as_user, timeout=None, can_retry=False, retry_count=0,
        relative=True):
    """Runs backup for_user, as_user.

    @param for_user: EVS user
    @param as_user: Local system user.
    @param timeout: In seconds, decides for how long backup should run.
    @param can_try: If backup fails, it can decide to retry

    """

    backup_restore.run(for_user=for_user, as_user=as_user, timeout=timeout,
                       can_retry=can_retry, retry_count=retry_count,
                       relative=relative, is_backup=True)


def get_progress(for_user, as_user):
    """Get backup progress information for a user.

    @return: UploadProgress - if progress info is available
    [] - if upload is in progress but progress info not available yet
    None - if no upload is going on.

    """

    return backup_restore.get_progress(for_user, as_user, is_backup=True)


def cancel_job(for_user, as_user):
    """Cancels an ongoing backup job."""

    return backup_restore.cancel_job(for_user, as_user, is_backup=True)
