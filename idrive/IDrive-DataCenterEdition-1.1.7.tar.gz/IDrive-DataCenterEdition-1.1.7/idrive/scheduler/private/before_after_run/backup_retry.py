"""Retry scheduled backup for certain failures"""

import datetime

from idrive.conf.settings import UserSettings
from idrive.core.evs.files.data_types.exceptions import \
    UploadAccountUnderMaintenanceError, UploadCommunicationError
from idrive.scheduler.data_types.job_schedule import JobSchedule
from idrive.scheduler.interface import add_job
from idrive.scheduler.private import BACKUP_JOB
from idrive.utils import log

_RETRY_DELAY = 1800  # 30 mins
_MAX_CUTOFF_DELTA = _RETRY_DELAY * 2
_MAX_RETRY_COUNT = 4


def retry_if_required(username, errors, cutoff_time=None, retry_count=0):
    """Retry backup for certain failure.

    This function registers a one time schedule job with scheduler and keeps
    count of previous retries

    @param username: Remote user for which to retry
    @param error: Errors reported by previous backup to calculate if we should
    retry
    @param cutoff_time: Time after which the backup should be stopped.
    @param retry_count: How many times to retry. This count will be decremented
    for the next call. If 0, max retry count of _MAX_RETRY_COUNT will be taken.

    """

    user_settings = UserSettings(username)
    try:
        _RETRY_DELAY = int(user_settings.BACKUP.retry_delay)
        _MAX_CUTOFF_DELTA = _RETRY_DELAY * 2
        _MAX_RETRY_COUNT = int(user_settings.BACKUP.max_retry_count)
    except (AttributeError, ValueError):
        pass

    if retry_count == 0:
        retry_count = _MAX_RETRY_COUNT
    else:
        retry_count -= 1

    if retry_count == 0:
        log.info("Max failure retries of {} reached. Will not retry again"
                 .format(_MAX_RETRY_COUNT),
                 mod_name=__name__)
    else:
        will_retry = False
        for error in errors:
            if isinstance(error, (UploadAccountUnderMaintenanceError,
                                  UploadCommunicationError)):
                will_retry = True

        # check if timeout is too short
        if cutoff_time is not None:
            now = datetime.datetime.now().replace(microsecond=0)
            cutoff_at = datetime.datetime.combine(now.date(), cutoff_time)
            cutoff_at = cutoff_at.replace(microsecond=0)

            # cutoff_at should be after _MAX_CUTOFF_DELTA so that
            #  backup can run at least _MAX_CUTOFF_DELTA - _RETRY_DELAY seconds
            if (cutoff_at <
                    (now + datetime.timedelta(seconds=_MAX_CUTOFF_DELTA))):
                will_retry = False
                log.error("Cutoff time too short to retry backup",
                          mod_name=__name__)

        if will_retry:
            start_time = (datetime.datetime.now() +
                          datetime.timedelta(seconds=_RETRY_DELAY)).time()

            # Add a one time job to scheduler to run after _RETRY_DELAY
            job_schedule = JobSchedule([], start_time, cutoff_time)
            add_job(BACKUP_JOB, username, job_schedule, retry_count)

            log.info("Will retry backup at '{}'"
                     .format(start_time.strftime('%X')), mod_name=__name__)
