'''
setup.py - install the datacenter application on your system
'''

import platform
import sys

if sys.version_info[0] != 2 or sys.version_info[1] != 7:
    sys.stderr.write("Error: Minimum requirement of python 2.7 not met.\n")
    sys.exit(1)

try:
    from setuptools import setup, find_packages
except ImportError:
    sys.stderr.write("Error: setuptools requirement not met.\n")
    sys.exit(1)

LDB = __import__('idrive')
version = LDB.get_version()

PKGS_TO_EXCLUDE = ['idrive.clu', 'idrive.clu.*', 'idrive.test', 'idrive.test.*',
                   'idrive.webui.web_sys', 'idrive.webui.web_sys.*']
PACKAGE_DATA = {'idrive.conf': ['*.ini'],
                'idrive.core.evs.idevsutil.executable': ['*'],
                'idrive.flavors': [LDB.flavors.DEFAULTS, LDB.flavors.CURRENT],
                'idrive.proxy.private': ['command_mappings.json'],
                'idrive.templating': ['templates/*/*'],
                'idrive.webui': ['static/css/*',
                              'static/docs/*.html', 'static/docs/*.js',
                              'static/docs/*.inv',
                              'static/docs/*/*.html', 'static/docs/*/*.js',
                              'static/docs/*/*.css', 'static/docs/*/*.png',
                              'static/docs/*/*.gif', 'static/docs/*/*.txt',
                              'static/docs/*/*/*.txt',
                              'static/img/*/*.*', 'static/img/*/*/*.*',
                              'static/js/build/site.min.js',
                              'static/js/build/site.min.js.map'],
                'idrive.webui.app.views': ['*/*.html', '*/*/*.html', '*/*.json'],
                'idrive.session_log.data_types': ['record.xml']}
ENTRY_POINTS = {'console_scripts': [
    LDB.SHORT_NAME + '_admin.py = idrive.bin.admin:execute',
    LDB.SHORT_NAME + '_sched.py = idrive.bin.sched:execute',
    LDB.SHORT_NAME + '_proxy.py = idrive.bin.proxy:execute',
    LDB.SHORT_NAME + '_websrvr.py = idrive.bin.websrvr:execute'
]}

pyopenssl_version = '>=0.15.1'
try:
    # For centos 5.x, use pyopenssl==0.12
    distname, distversion, _ = platform.linux_distribution()
    if 'CentOS' in distname and float(distversion) < 6:
        pyopenssl_version = '==0.12'
except ValueError:
    pass

INSTALL_REQUIRES = ['apscheduler==2.1.2',
                    'flask==0.10.1',
                    'jinja2>=2.4,<3.0',
                    'pycrypto==2.6.1',
                    'python-daemon==1.6.0',
                    'pam==0.1.4',
                    'setuptools>=5.0',
                    'Werkzeug>=0.10.0',
                    'WTForms>=2.0.0',
                    'pyopenssl{}'.format(pyopenssl_version)]

setup(name=LDB.PKG_NAME,
      version=version,
      url=LDB.URL,
      license='LICENSE',
      maintainer=LDB.SHORT_NAME,
      maintainer_email=LDB.EMAIL,
      packages=find_packages(exclude=PKGS_TO_EXCLUDE),
      package_data=PACKAGE_DATA,
      entry_points=ENTRY_POINTS,
      zip_safe=False,
      install_requires=INSTALL_REQUIRES)
