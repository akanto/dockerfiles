'''ldb.scheduler.data_types.exceptions'''

from idrive.core.evs.files.data_types.exceptions import UploadError, DownloadError


class _NoSetError(Exception):
    '''base exception for running backup/restores with empty set'''
    pass


class NoBackupSetError(_NoSetError, UploadError):
    '''for running backup with empty set'''

    def __init__(self, message='No files/folders selected to backup'):
        super(NoBackupSetError, self).__init__(message)


class NoRestoreSetError(_NoSetError, DownloadError):
    '''for running restore with empty set'''

    def __init__(self, message='No files/folders selected to restore'):
        super(NoRestoreSetError, self).__init__(message)


class TransferError(Exception):
    '''all errors in the starting of a backup/restore'''
    pass
