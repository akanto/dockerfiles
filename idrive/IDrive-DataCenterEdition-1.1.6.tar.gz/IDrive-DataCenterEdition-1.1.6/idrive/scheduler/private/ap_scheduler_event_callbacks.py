"""Event callbacks from apscheduler."""

import idrive.utils.log as log


def job_added_callback(job_store_event):
    """Called when a job is added."""

    log.debug("New job added to '{}'".format(job_store_event.alias),
              mod_name=__name__)
