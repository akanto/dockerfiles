"""Before running backup/restore"""

from idrive.conf.settings import UserSettings


def before_run(is_backup):
    """NOTE: Should be called only after doing setuid() before a
    backup/restore operation

    @param is_backup: True if its a backup operation, False otherwise
    @return: dict of parameters/values required by by the
    backup/restore operation

    """

    settings = {}
    if is_backup:
        try:
            bandwidth = int(UserSettings().LOCAL.upload_bandwidth)
        except (AttributeError, ValueError):
            bandwidth = 100
        settings['bandwidth'] = bandwidth

    return settings
