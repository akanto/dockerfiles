"""After running backup/restore"""

import platform
import datetime

from idrive.scheduler.private.before_after_run import after_actions
from idrive.scheduler.private.before_after_run.summary_renderer import \
    SummaryRenderer
from idrive.scheduler.private.before_after_run.backup_notification import \
    send_notification_email
from idrive.scheduler.private.before_after_run.backup_retry import \
    retry_if_required
from idrive.session_log.data_types import LogRecord
from idrive.session_log.interface import add_log_record, add_log_details
from idrive.utils import log


_REASON_COMMUNICATION = u'There was a communication error during the %s'
_REASON_MAINTENANCE = u'Your account is under maintenance'
_REASON_NO_SET = u'No files/folders selected to %s'
_REASON_CANCELLED = u'The %s job was cancelled by user'
_REASON_CUTOFF = (u'The %s job was cancelled as it did not finish by the '
                  u'cutoff time %s')
_REASON_THRESHOLD = (u'The number of file errors (%d) was greater than your '
                     u'failure threshold (max %d)')
_REASON_GENERIC = u'An unknown error occurred during the %s'


def after_run(is_backup, backup_restore_job, files, errors, start_time,
              end_time, timeout=None, retry=False, retry_count=0):
    '''
    Various actions to be taken after a backup/restore has finished

    @note: Should be called after backup/restore operation (so will be
        after doing setuid())

    @param is_backup: True for backup, false otherwise
    @param backup_restore_job: The backup/restore job
    @param files: list of files transferred
    @param errors: list of errors during the transfer
    @param start_time: When did the operation start
    @param end_time: When did the operation end
    @param timeout: Timeout in seconds after which this operation was supposed
        to stop since start_time
    @param retry: Can we retry operation if it failed? Decision should be
        made here.
    '''
    username, password, _ = backup_restore_job.login_data.get()

    # default results
    analyzer = after_actions.TransferAnalyzer(files, errors)
    error = None
    upload_logs = True
    cancelled = False
    operation = 'backup' if is_backup else 'restore'
    cutoff = None
    if timeout is not None:
        cutoff = (start_time + datetime.timedelta(seconds=timeout)).time()
    computer_name = platform.node().split('.')[0]

    # analyze the results
    if analyzer.is_communication_error():
        error = _REASON_COMMUNICATION % (operation)
        upload_logs = False
    elif analyzer.is_under_maintenance():
        error = _REASON_MAINTENANCE
        upload_logs = False
    elif analyzer.has_no_transfer_set():
        error = _REASON_NO_SET % (operation)
        retry = False  # no retry if we got nothing to backup
    elif analyzer.is_cancelled():
        cancelled = True
        retry = False
        # cancelled by who?
        if timeout is None:
            error = _REASON_CANCELLED % (operation)
        else:
            error = _REASON_CUTOFF % (operation, cutoff.strftime('%I:%M %p'))
    elif analyzer.over_error_threshold():
        error = _REASON_THRESHOLD % (analyzer.file_errors(),
                                     analyzer.get_threshold())
    elif analyzer.unknown_errors():
        if analyzer.files_in_sync() + analyzer.files_transferred() < 1:
            error = _REASON_GENERIC % (operation)
        # we definitely need to log that something weird happened.
        # @see bug 384 and 399 for more information
        log.error(_REASON_GENERIC % (operation + '. Details below:'),
                  mod_name=__name__)

    after_actions.log_transfer_errors(errors)
    log.debug(u'Finished analyzing %s' % (operation), mod_name=__name__)

    # view vars
    renderer = SummaryRenderer()
    summary_vars = {
        'is_backup': is_backup,
        'error': error,
        'file_total': analyzer.total_files(),
        'files_in_sync': analyzer.files_in_sync(),
        'files_transferred': analyzer.files_transferred(),
        'file_errors': analyzer.file_errors()
    }

    # record to session log
    try:
        log_record = LogRecord()
        log_record.op_successful = (error is None)
        log_record.op_cancelled = cancelled
        log_record.operation = (
            LogRecord.OP_BACKUP if is_backup else LogRecord.OP_RESTORE
        )
        log_record.computer_name = computer_name
        log_record.username = username
        log_record.op_start_time = start_time
        log_record.op_end_time = end_time
        log_details = renderer.render('scheduler/transfer_summary_log.txt',
                                      files=files, errors=errors,
                                      **summary_vars)

        add_log_record(log_record)
        add_log_details(log_record, log_details, upload_logs)
    except ValueError as e:
        log.error(u'Error in creating a LogRecord: %s' % (str(e)),
                  mod_name=__name__)
    else:
        log.debug(u'Updated session logs', mod_name=__name__)

    # following apply only for backups for now
    if is_backup:
        email_subject = \
            renderer.render('scheduler/transfer_summary_email_subject.txt',
                            failed=(error is not None),
                            is_backup=is_backup, end_time=end_time)
        email_summary = renderer.render('scheduler/transfer_summary_email.txt',
                                        username=username,
                                        computer_name=computer_name,
                                        start_time=start_time,
                                        end_time=end_time,
                                        success=(error is None),
                                        **summary_vars)
        send_notification_email((error is None), username, password,
                                email_subject, email_summary)

        # was there any error? if so, initiate retry
        if error is not None and retry:
            retry_if_required(username, errors, cutoff, retry_count)
