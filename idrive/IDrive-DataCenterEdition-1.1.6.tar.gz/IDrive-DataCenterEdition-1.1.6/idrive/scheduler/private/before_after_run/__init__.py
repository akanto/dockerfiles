"""Operations to do before and after running backup"""
