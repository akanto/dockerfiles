'''certificate module'''

import ssl
import sys

from OpenSSL import crypto
from random import random

_VALID_DAYS = 365
_KEY_LENGTH = 2048
_MESSAGE_DIGEST = 'sha256'
_CIPHER_LIST = 'HIGH'


def generate_ssl_pair(cn=None):
    '''Generates an SSL certificate & key file'''

    # pretty damn sure that this is not actually accepted by anyone
    if cn is None:
        cn = '*'

    cert = crypto.X509()
    cert.set_serial_number(int(random() * sys.maxint))
    cert.gmtime_adj_notBefore(0)
    cert.gmtime_adj_notAfter(60 * 60 * 24 * _VALID_DAYS)

    subject = cert.get_subject()
    subject.CN = cn
    subject.O = 'Self-Signed Certificate'

    issuer = cert.get_issuer()
    issuer.CN = 'IDrive Inc. Self Signed Authority'
    issuer.O = 'Self-Signed'

    pkey = crypto.PKey()
    pkey.generate_key(crypto.TYPE_RSA, _KEY_LENGTH)
    cert.set_pubkey(pkey)
    cert.sign(pkey, _MESSAGE_DIGEST)

    return cert, pkey


def make_ssl_cert(base_path, host=None, cn=None):
    '''Generates an SSL certificate'''

    if host is not None:
        cn = '*.%s/CN=%s' % (host, host)
    cert, pkey = generate_ssl_pair(cn=cn)

    cert_file = base_path + '.crt'
    pkey_file = base_path + '.key'

    with open(cert_file, 'w') as f:
        f.write(crypto.dump_certificate(crypto.FILETYPE_PEM, cert))
    with open(pkey_file, 'w') as f:
        f.write(crypto.dump_privatekey(crypto.FILETYPE_PEM, pkey))

    return cert_file, pkey_file


def make_context(certificate_file, private_key_file):
    '''Creates an SSL context

    @return: tuple of (certificate_file, private_key_file, protocol)
    '''
    best_protocol = None
    # build list of protocols by name since we support multiple SSL versions
    protocols = ['PROTOCOL_TLSv1_2', 'PROTOCOL_TLSv1_1', 'PROTOCOL_TLSv1',
                 'PROTOCOL_SSLv3', 'PROTOCOL_SSLv23']
    for protocol in protocols:
        try:
            best_protocol = getattr(ssl, protocol)
            break
        except AttributeError:
            pass
    else:
        raise RuntimeError('No appropriate SSL protocol found')

    return (certificate_file, private_key_file, best_protocol)
