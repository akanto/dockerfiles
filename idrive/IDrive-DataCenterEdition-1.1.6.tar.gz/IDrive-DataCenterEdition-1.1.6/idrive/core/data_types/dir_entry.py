""""Encapsulates a file/folder object, both remote and local."""

import os
import hashlib

from datetime import datetime


class DirEntry(object):
    """Directory entry representing a file or folder

    isfile, size and modified date are automatically
    filled up from system if not provided. File/folder
    must exist in system if only name is provided.

    Attributes:
        name            <type 'string'>. Full path of file/folder
        isfile          <type 'bool'>.
        modified_date   <type 'datetime'>
        size            <type int>. Size in bytes
        can_read        <type bool>. Optional.

    """

    def __init__(self, name, isfile=None, modified_date=None, size=None,
                 can_read=None):
        """Constructor.

        If only name is given, rest of the attributes are filled
        up from system. Otherwise, all attributes must be passed.
        modified_date can be UNIX timestamp, string representing date
        or datetime object. size must be int, and isfile bool

        isfile is None if entry is neither a regular file, nor a directory

        DirEntry automatically expands a symlink to the real path

        can_read is optional, unlike the other three params, isfile,
        modified_date and size when creating DirEntry directly.

        """

        # Accept both unicode as well as non unicode,
        # but internally only use unicode
        if not isinstance(name, unicode):
            name = name.decode('utf8')

        name = os.path.normpath(name)
        if not os.path.isabs(name):
            raise ValueError("name must be absolute path")

        # only name provided
        if isfile is None and modified_date is None and size is None:
            if not os.path.exists(name):
                raise ValueError("{} : file/folder does not exist"
                                 .format(name))

            self.islink = os.path.islink(name)
            self.linkpath = name if self.islink else None
            self.name = os.path.realpath(name)
            self.isfile = None
            if os.path.isdir(self.name):
                self.isfile = False
            elif os.path.isfile(self.name):
                self.isfile = True
            self.size = os.path.getsize(self.name)
            self.modified_date = \
                datetime.fromtimestamp(os.path.getmtime(self.name))
            self.can_read = os.access(self.name, os.R_OK)

        # otherwise all must be provided
        elif None in [isfile, modified_date, size]:
            raise ValueError("Must provide all argument or only name")

        else:
            self.name = name
            self.isfile = bool(isfile)
            self.can_read = can_read

            try:
                self.size = int(size)
            except ValueError:
                raise ValueError("Invalid data for size : " + size)

            try:
                if isinstance(modified_date, datetime):
                    self.modified_date = modified_date
                elif isinstance(modified_date, float):
                    self.modified_date = datetime.fromtimestamp(modified_date)
                else:
                    self.modified_date = \
                        datetime.strptime(modified_date, "%Y/%m/%d %H:%M:%S")
            except ValueError:
                raise ValueError("Invalid data for date : " + modified_date)

    def __hash__(self):
        """Object id."""

        return int(hashlib.md5(self.name.encode('utf8')).hexdigest(), 16)

    def __eq__(self, other):
        """Equal comparison."""

        if isinstance(other, DirEntry):
            return self.name == other.name
        raise NotImplementedError("Cannot compare {} with {}"
                                  .format(type(self), type(other)))

    def __ne__(self, other):
        """Not equal comparison"""

        if isinstance(other, DirEntry):
            return self.name != other.name
        raise NotImplementedError("Cannot compare {} with {}"
                                  .format(type(self), type(other)))

    def __lt__(self, other):
        """Less than < comparison"""

        if isinstance(other, DirEntry):
            return self.name < other.name
        raise NotImplementedError("Cannot compare {} with {}"
                                  .format(type(self), type(other)))

    def __gt__(self, other):
        """Greater than > comparison"""

        if isinstance(other, DirEntry):
            return self.name > other.name
        raise NotImplementedError("Cannot compare {} with {}"
                                  .format(type(self), type(other)))

    def __str__(self):
        """String representation of the file object"""

        return ('{name} || '
                '{size} bytes || '
                '{lmd}').format(name=self.name.encode('utf8'), size=self.size,
                                lmd=self.modified_date.strftime('%c'))

    def __repr__(self):

        return str(self)
