"""Basic data types used within core package."""


from idrive.core.data_types.dir_entry import DirEntry
