"""ServerAddress class."""

from idrive.core.evs.idevsutil.data_types import EVSResponse


class ServerAddress(EVSResponse):
    """Encapsulates the server details of any user.

    Automatically extracts the relevant server addresses from
    the xml produced by idevsutil.

    """

    def __init__(self, xml_string):
        """Constructor."""

        super(ServerAddress, self).__init__(xml_string)

        try:
            self.CLU_SERVER_HOST = self.xml.get('cmdUtilityServer')
            self.CLU_SERVER_IP = self.xml.get('cmdUtilityServerIP')
            self.REST_SERVER_HOST = self.xml.get('webApiServer')
            self.REST_SERVER_IP = self.xml.get('webApiServerIP')
        except AttributeError:
            raise ValueError('Insufficient data : {resp}'
                             .format(resp=xml_string))

        if None in [self.CLU_SERVER_HOST, self.CLU_SERVER_IP,
                    self.REST_SERVER_HOST, self.REST_SERVER_IP]:
            raise ValueError('Insufficient data : {resp}'
                             .format(resp=xml_string))
