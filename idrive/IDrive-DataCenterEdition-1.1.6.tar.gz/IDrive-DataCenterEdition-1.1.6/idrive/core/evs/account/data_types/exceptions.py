"""All Exception classes for account package."""

from idrive.core.evs.idevsutil.data_types import EVSError


class ServerAddressError(EVSError):
    """Exception from server_address module."""
    pass


class ServerAddressLoginError(ServerAddressError):
    """Specializes invalid username/password error"""
    pass


class ValidateAccountError(EVSError):
    """Encapsualtes validation errors."""
    pass


class ValidateAccountLoginError(ValidateAccountError):
    """Specializes invalid username/password error"""
    pass


class ConfigureAccountError(EVSError):
    """Encapsulates configure account errors."""
    pass


class ConfigureAccountLoginError(ConfigureAccountError):
    """Specializes invalid username/password error"""
    pass


class ConfigureAccountAlreadyConfiguredError(ConfigureAccountError):
    """Specializes YOUR ACCOUNT IS ALREADY CONFIGURED error"""
    pass


class QuotaError(EVSError):
    """Exception from quota module."""
    pass


class QuotaLoginError(QuotaError):
    """Specializes invalid username/password error"""
    pass
