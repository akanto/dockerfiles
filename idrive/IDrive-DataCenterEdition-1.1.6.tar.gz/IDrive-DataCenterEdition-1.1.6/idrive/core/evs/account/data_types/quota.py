"""Encapsulates quota of a user."""

from __future__ import division

from idrive.utils.size_format import size_format
from idrive.core.evs.idevsutil.data_types import EVSResponse


class Quota(EVSResponse):
    """Encapsulate quota of a user."""

    def __init__(self, xml_string=None):
        """Constructor."""

        super(Quota, self).__init__(xml_string)

        try:
            self.MAX_QUOTA = int(self.xml.get('totalquota'))
            self.MAX_QUOTA_FORMAT = size_format(self.MAX_QUOTA)
            self.USED_QUOTA = int(self.xml.get('usedquota'))
            self.USED_QUOTA_FORMAT = size_format(self.USED_QUOTA)
            self.FILE_COUNT = int(self.xml.get('filecount'))
            self.PERCENT = round(self.USED_QUOTA / self.MAX_QUOTA * 100, 1)
        except (TypeError, AttributeError):
            raise ValueError("Insufficient data : {xml}"
                             .format(xml=xml_string))
