'''Download file(s) from EVS'''

import os
import sys

from idrive.core.evs.account import get_server_address, ServerAddressError
from idrive.core.evs.account.data_types.exceptions import ServerAddressLoginError
from idrive.core.evs.files.data_types import DownloadProgress, DownloadError
from idrive.core.evs.files.data_types.exceptions import DownloadLoginError, \
    DownloadInvalidPathError, DownloadAccountUnderMaintenanceError, \
    SearchLoginError, SearchAccountUnderMaintenanceError, \
    DownloadCancelledError, DownloadCommunicationError, \
    SearchCommunicationError
from idrive.core.evs.files.search import search_files, SearchError
from idrive.core.evs.idevsutil import execute_command, DOWNLOAD, VERSION_ID, \
    CANCEL_OP
from idrive.core.evs.idevsutil.data_types import EVSErrorFactory, \
    EVSInvalidPathError, EVSInvalidServerError, EVSMultipleError, EVSError, \
    EVSLoginError, EVSAccountUnderMaintenanceError, EVSCommunicationError
from idrive.utils.bunch import Bunch


def _download_callback(callback, success_xml, error_xml):
    '''
    Internal callback function
    @param callback: callback function to call
    @param success_xml: successfull XML data
    @param error_xml: error XML data
    '''
    error_list = []
    if error_xml:
        for error_xml_line in error_xml.split('\n'):
            try:
                raise EVSErrorFactory.get_error(error_xml_line)
            except EVSInvalidPathError as err:
                error_list.append(DownloadInvalidPathError(err))
            except EVSAccountUnderMaintenanceError as err:
                error_list.append(DownloadAccountUnderMaintenanceError(err))
            except EVSCommunicationError as err:
                error_list.append(DownloadCommunicationError(err))
            except EVSMultipleError as err:
                for error in err:
                    if isinstance(error, EVSInvalidPathError):
                        error_list.append(DownloadInvalidPathError(error))
                    else:
                        error_list.append(DownloadError(error))
            except EVSError as err:
                error_list.append(DownloadError(err))

    if error_list:
        callback(error_list)

    success_list = []
    if success_xml:
        for success_xml_line in success_xml.split('\n'):
            if success_xml_line:
                success_list.append(DownloadProgress(success_xml_line))

    if success_list:
        callback(success_list)


def _build_file_list(username, password, dir_entry_list, pvtkey=None):
    '''Internal function to build the file list.

    Download only works with full file path, not directory names.
    This function does a search on each directory path and builds
    a list of file paths.
    '''
    file_list = []
    error_list = []

    for dir_entry in dir_entry_list:
        if dir_entry.isfile:
            name = dir_entry.name
            # always specify which version to download
            name += VERSION_ID.format(dir_entry.version)

            file_list.append(name)
        else:
            try:
                # Note: Trailing '/' in search_path is important. Bug # 270
                search_list = search_files(username, password, search_for='*',
                                           search_path=dir_entry.name + '/',
                                           in_trash=False)
            except SearchLoginError as err:
                raise DownloadLoginError(err)
            except SearchAccountUnderMaintenanceError as err:
                raise DownloadAccountUnderMaintenanceError(err)
            except SearchCommunicationError as err:
                raise DownloadCommunicationError(err)
            except SearchError as err:
                _, _, tb = sys.exc_info()
                raise DownloadError(err), None, tb
            else:
                has_files = False
                for search_entry in search_list:
                    if search_entry.isfile:
                        name = search_entry.name
                        if search_entry.version > 1:
                            name += VERSION_ID.format(search_entry.version)

                        file_list.append(name)
                        has_files = True

                if not has_files:
                    # no files
                    error_list.append(
                        DownloadInvalidPathError(
                            Bunch({'path': dir_entry.name,
                                   'message': 'No files found in folder'})))

    return file_list, error_list


def download(username, password, local_path, dir_entry_list, pvtkey=None,
             callback=None, relative=None, cancel_lambda=None):
    '''Download files from EVS.

    @param username: EVS username
    @param password: EVS password
    @param file_list: list of file/folder path to delete.
    @param pvtkey: Private key. Optional.
    @param local_path: where to download the file on the local machine.
    We will try to create it if it does not exist.
    @param dir_entry_list: a list of EVSDirEntries to download
    @param callback: can be used to monitor progress of download.
    It is periodically called with lists of DownloadProgress
    and DownloadError objects as the case might be.
    @param relative: Download will be relative to local path?
    @param cancel_lambda: can be used to cancel the download process.
    It can be any object with one attribute, 'call', which
    will be assigned a function. The caller can then just call
    cancel_lambda.call() to cancel the upload.

    @return: <tuple> list of DownloadProgress objects, list of DownloadErrors

    @raise DownloadLoginError: Invalid username/password
    @raise DownloadInvalidPath: Invalid local path
    @raise DownloadAccountUnderMaintenanceError: Account under maintenance
    @raise DownloadError: All other errors
    '''

    if not os.path.exists(local_path):
        try:
            os.makedirs(local_path)
        except OSError as err:
            raise DownloadError(str(err))
    elif not os.path.isdir(local_path):
        raise DownloadError("Download location is not a folder")

    if not isinstance(dir_entry_list, list):
        raise DownloadError("Invalid 'dir_entry_list'")

    # Retry with cached=False for EVSInvalidServerError
    for cached in [True, False]:
        try:
            server_address = get_server_address(username, password, cached)
        except ServerAddressLoginError as err:
            raise DownloadLoginError(err)
        except ServerAddressError as err:
            _, _, tb = sys.exc_info()
            raise DownloadError(err), None, tb

        # vars
        progress_list = []
        ipaddress = server_address.CLU_SERVER_IP
        check_cancel = None

        progress_callback = None
        if callback is not None:
            progress_callback = lambda s, e: _download_callback(callback, s, e)

        if cancel_lambda is not None and hasattr(cancel_lambda, 'call'):
            check_cancel = {'filename': False, 'cancelled': False}

            def cancel_download():
                if check_cancel['filename']:
                    with open(check_cancel['filename'], 'w') as f:
                        f.write(CANCEL_OP)
                check_cancel['cancelled'] = True

            cancel_lambda.call = cancel_download

        # build the list of files to download
        file_list, error_list = _build_file_list(username, password,
                                                 dir_entry_list, pvtkey)

        # give the callback information right away for errors
        if error_list and callback:
            callback(error_list)

        # no files? bail out now
        if not file_list:
            return progress_list, error_list

        try:
            succ_xml, err_xml = execute_command(DOWNLOAD, username, password,
                                                pvtkey=pvtkey,
                                                server_address=ipaddress,
                                                local_path=local_path,
                                                file_list=file_list,
                                                relative=relative,
                                                callback=progress_callback,
                                                check_cancel=check_cancel)

            if check_cancel and check_cancel['cancelled']:
                error = DownloadCancelledError()
                if callback is not None:
                    callback([error])
                else:
                    raise error

            if err_xml:
                raise EVSErrorFactory.get_error(err_xml)

        except EVSLoginError as err:
            raise DownloadLoginError(err)
        except EVSAccountUnderMaintenanceError as err:
            raise DownloadAccountUnderMaintenanceError(err)
        except EVSCommunicationError as err:
            raise DownloadCommunicationError(err)
        except EVSInvalidPathError as err:
            error_list.append(DownloadInvalidPathError(err))
            break
        except EVSMultipleError as err:
            for error in err:
                if isinstance(error, EVSInvalidPathError):
                    error_list.append(DownloadInvalidPathError(error))
                else:
                    error_list.append(DownloadError(error))
            break
        except DownloadCancelledError as e:
            error_list.append(e)
            break
        except EVSInvalidServerError as err:
            if cached:
                continue
            else:
                raise DownloadError(err)
        except EVSError as err:
            _, _, tb = sys.exc_info()
            raise DownloadError(err), None, tb
        else:
            break

    if callback is None:
        for xml_line in succ_xml.split('\n'):
            if xml_line:
                progress_list.append(DownloadProgress(xml_line))

    return progress_list, error_list

if __name__ == '__main__':
    import cPickle as pickle

    from idrive.utils.command_line import process_command_line

    required_args = {'username', 'password', 'local-path', 'dir-entry-list'}
    optional_args = {'callback', 'relative.store'}
    kwargs = process_command_line(required_args, optional_args)

    # Create callback if callback is set
    if kwargs['callback']:

        def dump_flist(f_list):
            pkled_f_list = pickle.dumps(f_list)
            # In callback, write length of each batch first
            print len(pkled_f_list)
            print pkled_f_list

        kwargs['callback'] = dump_flist
    else:
        kwargs['callback'] = None

    try:
        progress_list, error_list = download(**kwargs)
    except (DownloadError) as err:
        sys.stderr.write(pickle.dumps(err))
        sys.exit(1)
    else:
        if progress_list:
            print pickle.dumps(progress_list)
        if error_list:
            sys.stderr.write(pickle.dumps(error_list))
            sys.exit(1)
