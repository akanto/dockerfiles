'''Restore result class'''

import re

from idrive.core.evs.files.data_types.exceptions import RestoreError
from idrive.core.evs.idevsutil.data_types import EVSResponse


class RestoreResult(object):
    """ Encapsulates restore result.

    """

    def __init__(self, xml_string):
        """Constructor."""

        xml_string = re.sub('>[^<]*<', '>\n<', xml_string.strip(),
                            flags=re.DOTALL)

        self.result = []
        tot_items_moved = 0
        tot_items_moved_cnt = 0

        for xml_line in xml_string.split('\n'):
            xml = EVSResponse(xml_line).xml
            if xml is None:
                raise RestoreError("Invalid response from EVS : "
                                   .format(xml_string))

            if xml.tag == 'item':
                if 'op' in xml.attrib:
                    if (xml.get('op') != 'moved successfully' or
                            'fname' not in xml.attrib):
                        raise RestoreError('Invalid response from EVS : {}'
                                           .format(xml_string))
                    else:
                        self.result.append({'name': xml.get('fname'),
                                            'success': True})
                        tot_items_moved_cnt += 1

                if 'tot_items_moved' in xml.attrib:
                    tot_items_moved = int(xml.get('tot_items_moved'))

            elif xml.tag == 'tree':
                if 'path' in xml.attrib:
                    self.result.append({'name': xml.get('path'),
                                        'success': False})
                else:
                    raise RestoreError("Invalid response from EVS : "
                                       .format(xml_string))

        if len(self.result) == 0 or tot_items_moved != tot_items_moved_cnt:
            raise RestoreError("Invalid response from EVS : " + (xml_string))
