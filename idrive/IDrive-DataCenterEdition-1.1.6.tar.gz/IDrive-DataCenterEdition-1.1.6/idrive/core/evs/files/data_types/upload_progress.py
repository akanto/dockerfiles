"""Encapsulates upload progress"""

from idrive.core.evs.files.data_types.exceptions import \
    UploadDownloadError, UploadError
from idrive.core.evs.files.data_types.private.upload_download_progress import \
    UploadDownloadProgress, SYNC, INCREMENTAL, FULL  # @UnusedImport


class UploadProgress(UploadDownloadProgress):
    """For representing an upload progress.

    NOTE: the 'name' data member will only contain the basename
    of the upload path provided during a call to upload when uploads
    are non-relative, which is by default. The rest of path will
    have to be prepended by the consumer of this class.

    e.g upload(..., file_list=['/root/subroot1/subroot1']) will generate
    UploadProgress data with name starting with subroot1/...

    For relative uploads, progress data starts from root without the leading
    /.

    """

    def __init__(self, xml_string):
        # All functionality is handled in the base class
        try:
            super(UploadProgress, self).__init__(xml_string)
        except UploadDownloadError as err:
            raise UploadError(err)
