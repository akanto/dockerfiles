"""Common class for handling progress data"""

from idrive.core.evs.files.data_types.exceptions import UploadDownloadError
from idrive.core.evs.idevsutil.data_types import EVSResponse

SYNC = 'SYNC'
INCREMENTAL = 'INCREMENTAL'
FULL = 'FULL'

_transfer_type = {
    None: 'SYNC',
    'FILE IN SYNC': SYNC,
    'INCREMENTAL': INCREMENTAL,
    'FULL': FULL
}


class UploadDownloadProgress(EVSResponse):
    """Common class for handling progress data.

    UploadProgress and DownloadProgresss should derive from this
    class.

    """

    def __init__(self, xml_string):
        """Constructor."""

        super(UploadDownloadProgress, self).__init__(xml_string)

        try:
            # NOTE: fname will only have the basename() of the path
            #  if upload is not relative which is by default
            self.name = self.xml.get('fname')
            self.transfer_type = _transfer_type[self.xml.get('trf_type')]

            # Current file progress
            self.filesize = int(self.xml.get('size'))
            try:
                self.transferred_filesize = int(self.xml.get('offset'))
            except TypeError:
                self.transferred_filesize = int(self.xml.get('size'))
            self.complete = not (self.filesize - self.transferred_filesize)

            # Total transfer progress
            self.totalsize = int(self.xml.get('tot_sz'))
            self.transferred_totalsize = int(self.xml.get('tottrf_sz'))
        except (ValueError, AttributeError, TypeError):
            raise UploadDownloadError(u'Insufficient data : {resp}'
                                      .format(resp=xml_string))

        if None in [self.name, self.transfer_type, self.filesize,
                    self.transferred_filesize, self.totalsize,
                    self.transferred_totalsize]:
            raise UploadDownloadError(u'Insufficient data : {resp}'
                                      .format(resp=xml_string))
