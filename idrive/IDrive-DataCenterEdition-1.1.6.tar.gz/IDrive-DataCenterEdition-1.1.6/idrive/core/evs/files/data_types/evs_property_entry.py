"""Encapsulates property entry received from EVS"""

import os
import re

from idrive.core.data_types import DirEntry
from idrive.core.evs.idevsutil.data_types import EVSResponse


class EVSPropertyEntry(DirEntry):
    """Encapsulates file/folder properties entry retrieved from EVS

       Attributes:
        name            Inherited from PropertyEntry
        isfile          Inherited from PropertyEntry
        size            Inherited from PropertyEntry
        modified_date   Inherited from PropertyEntry
        files_count     <type 'int'>: Number of files in a folder
        create_date     <type datetime> stores create_time
        access_date     <type datetime> stores access_time

    """

    def __init__(self, xml_string, path):
        """Creates an EVSPropertyEntry object

        @param xml_string: a valid xml entry passed by idevsutil module
        @param path: required as xml_entry doesn't contain path
        """

        xml_string = re.sub('>[^<]*<', '>\n<', xml_string.strip(),
                            flags=re.DOTALL)

        name = os.path.normpath(path)
        isfile = True
        create_date = None
        mod_date = None
        access_date = None
        files_count = None
        size = 0

        for xml_line in xml_string.split('\n'):
            xml = EVSResponse(xml_line).xml

            if xml is None:
                raise ValueError("Invalid XML : " + xml_line)

            isfile = isfile if xml.get('files_count') is None else False
            if xml.get('size') is not None:
                size = xml.get('size')
                size = re.sub(' bytes', '', size)
                size = int(size)
            if xml.get('create_time') is not None:
                create_date = xml.get('create_time')
            if xml.get('mod_time') is not None:
                mod_date = xml.get('mod_time')
            if xml.get('access_time') is not None:
                access_date = xml.get('access_time')
            if xml.get('files_count') is not None:
                files_count = xml.get('files_count')
                files_count = int(files_count)

        super(EVSPropertyEntry, self).__init__(name, isfile, create_date, size)
        self.mod_date = mod_date
        self.access_date = access_date
        self.create_date = create_date
        if not isfile:
            self.files_count = files_count
