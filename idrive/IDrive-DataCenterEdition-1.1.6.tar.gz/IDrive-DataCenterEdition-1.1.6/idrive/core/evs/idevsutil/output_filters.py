'''
output filters for idevsutil output
'''

import re

STDOUT = 0
STDERR = 1

'''
this list is used to convert output messages into a standard format. Some
error messages come in stdout of idevsutil. Those are marked with @E in the
start of line so that idevsutil._execute_command() can filter those lines out
via the error side of the result tuple.

note: the execution order matters here so take care where you insert new
filters. probably best to add at the end of the array unless you know what you
want to do.

its format is:
[
    {
        regex: {compiled regex expression to match},
        stdout: {stdout text substitution},
        stderr: {stderr text substitution}
    },
    ...
]
'''
_FILTERS = [
    # random text to ignore
    {
        'regex': re.compile(
            '^(connection established\s*'
            '|.*libpopt.*no version information available.*'
            '|building file list ... \s*'
            '|receiving file list ... \s*'
            '|sent.*bytes.*received.*bytes.*bytes/sec\s*'
            '|Unable to reach the server; account '
            '(validation|configuration) has failed\s*'
            '|idevs error: error starting client-server protocol.*'
            '|idevs error: auth list2.*'
            '|idevs: connection unexpectedly closed.*'
            '|skipping non-regular file.*'
            '|idevs error: some files could not be transferred.*'
            '|<item files_found.*'
            '|^[^\[]+], Reason: Permission denied\n'
            '|temporary file creation has failed.*'
            '|.*407 Proxy Authentication Required.*\n'
            '|\n)$', re.IGNORECASE
        ),
        STDOUT: '',
        STDERR: ''
    },
    # all bogus character before XML should be removed except lines starting
    # with "@E" which indicate errors
    {
        'regex': re.compile('^(?!@E)[^<]+<'),
        STDOUT: '<',
        STDERR: '<'
    },
    # 2 or more xml items on line should be separated
    {
        'regex': re.compile('>\s*<'),
        STDOUT: '>\n<',
        STDERR: '>\n<'
    },
    # quota auth failure message, need to convert to XML before returning
    {
        'regex': re.compile(
            '^@ERROR: auth failed.*password mismatch\s*$', re.IGNORECASE
        ),
        STDOUT:
            '@E<tree message="ERROR" desc="Invalid username or password"/>',
        STDERR: '<tree message="ERROR" desc="Invalid username or password"/>'
    },
    # when you give the wrong server address in the command, output needs to be
    # converted to XML
    {
        'regex': re.compile(
            '^@ERROR: auth.*unauthorized user\s*$', re.IGNORECASE
        ),
        STDOUT: '@E<tree message="ERROR" desc="Invalid server for user"/>',
        STDERR: '<tree message="ERROR" desc="Invalid server for user"/>'
    },
    # invalid path
    {
        'regex': re.compile(
            '^I?O?ERROR \[(?P<path>.*)\].*'
            '(?P<message>(No such file or directory|path not found))$',
            re.IGNORECASE
        ),
        STDOUT:
            '@E<tree message="ERROR" desc="\\g<message>" path="\\g<path>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>" path="\\g<path>"/>'
    },
    # comes in file versions and folder properties. similar to the "invalid
    # path" error except the path is not surrounded by "[" brackets
    {
        'regex': re.compile(
            '^ERROR\s(?P<path>.*)( : |, )'
            '(path not found|Reason: No such file or directory)$',
            re.IGNORECASE
        ),
        STDOUT:
            '@E<tree message="ERROR" desc="path not found" path="\\g<path>"/>',
        STDERR:
            '<tree message="ERROR" desc="path not found" path="\\g<path>"/>'
    },
    # no version found
    {
        'regex': re.compile('^No version found$', re.IGNORECASE),
        STDOUT: '@E<tree message="ERROR" desc="No versions found"/>',
        STDERR: '<tree message="ERROR" desc="No versions found"/>'
    },
    # create directory
    {
        'regex': re.compile(
            '^@ERROR: directory creation has failed.*:(?P<message>.*)$',
            re.IGNORECASE
        ),
        STDOUT: '@E<tree message="ERROR" desc="\\g<message>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>"/>'
    },
    # on rename when target exists. source doesn't exist has proper XML already
    {
        'regex': re.compile(
            '^@ERROR: rename failed, reason: (?P<message>.*)$', re.IGNORECASE
        ),
        STDOUT: '@E<tree message="ERROR" desc="\\g<message>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>"/>'
    },
    # permission denied error during upload
    {
        'regex': re.compile(
            '^SFERROR \[(?P<path>.*)\].*:\s*(?P<message>[^(\n]*).*$',
            re.IGNORECASE
        ),
        STDOUT:
            '@E<tree message="ERROR" desc="\\g<message>" path="\\g<path>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>" path="\\g<path>"/>'
    },
    # on copy or upload permission denied
    {
        'regex': re.compile(
            '^idevs: (push_dir|open|opendir) '
            '\[(?P<path>.*)\].*:(?P<message>[^(]*).*$',
            re.IGNORECASE
        ),
        STDOUT:
            '@E<tree message="ERROR" desc="\\g<message>" path="\\g<path>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>" path="\\g<path>"/>'
    },
    # copy failed
    {
        'regex': re.compile(
            '^copy failed for: \[(?P<path>.*)\]. Reason: (?P<message>.*)$',
            re.IGNORECASE
        ),
        STDOUT: '@E<tree message="ERROR" desc="\\g<message>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>"/>'
    },
    # Append @E to all error XML in stdout stream
    {
        'regex': re.compile(
            '(?P<error_xml>^<tree\s+message="ERROR".*$)',
            re.IGNORECASE
        ),
        STDOUT: '@E\\g<error_xml>',
        STDERR: '\\g<error_xml>'
    },
    # change 'op_status="failed"' to 'message="ERROR"' format
    {
        'regex': re.compile(
            '^<item\s+op_status="failed"(?P<error_xml>.*$)', re.IGNORECASE
        ),
        STDOUT: '@E<tree message="ERROR"\\g<error_xml>',
        STDERR: '<tree message="ERROR"\\g<error_xml>'
    },
    # invalid or no private key
    {
        'regex': re.compile(
            '^@ERROR: auth failed.*'
            '(?P<message>encryption verification failed)$',
            re.IGNORECASE
        ),
        STDOUT: '@E<item message="ERROR" desc="\\g<message>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>"/>'
    },
    # on connection to wrong or non existent server
    {
        'regex': re.compile(
            '^idevs error: (?P<message>error in idevs protocol data stream.*)',
            re.IGNORECASE
        ),
        STDOUT: '@E<item message="ERROR" desc="\\g<message>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>"/>'
    },
    {
        'regex': re.compile(
            '^idevs: (?P<message>getaddrinfo: .*: '
            'nodename nor servname provided, or not known)',
            re.IGNORECASE
        ),
        STDOUT: '@E<item message="ERROR" desc="\\g<message>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>"/>'
    },
    # network issues
    {
        'regex': re.compile(
            '^idevs: (?P<message>failed to connect.*)',
            re.IGNORECASE
        ),
        STDOUT: '@E<item message="ERROR" desc="\\g<message>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>"/>'
    },
    # network timeout
    {
        'regex': re.compile(
            (r'^(io timeout after [\d]+ seconds -- exiting|'
             r'idevs error: timeout in data send/receive .*)$'),
            re.IGNORECASE
        ),
        STDOUT: '@E<tree message="ERROR" desc="Network timeout"/>',
        STDERR: '<tree message="ERROR" desc="Network timeout"/>'
    },
    # socket IO error
    {
        'regex': re.compile(
            '^idevs error: (?P<message>error in socket IO.*)$', re.IGNORECASE
        ),
        STDOUT: '@E<item message="ERROR" desc="\\g<message>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>"/>'
    },
    # account under maintenance
    {
        'regex': re.compile(
            '^@ERROR: (?P<message>account is under maintenance)$',
            re.IGNORECASE
        ),
        STDOUT: '@E<item message="ERROR" desc="\\g<message>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>"/>'
    },
    # delete or restore for path "/"
    {
        'regex': re.compile(
            '^(?P<message>you are not allowed to '
            '(delete root account|move root account to original location) '
            'for the security reasons.*)$',
            re.IGNORECASE
        ),
        STDOUT: '@E<item message="ERROR" desc="\\g<message>"/>',
        STDERR: '<tree message="ERROR" desc="\\g<message>"/>'
    }
]


def clean(line, filter_key=STDOUT):
    '''
    Filters idevsutil output line by replacing the matched text with the
    appropriate substitution

    @param line:
        the text line
    @param filter_key:
        which substitution key to use (either STDOUT or STDERR)
    @return: the filtered line
    '''
    for filter_ in _FILTERS:
        line = filter_['regex'].sub(filter_[filter_key], line)

    return line
