"""Encapsulates a collection of LogRecord objects"""

import xml.etree.ElementTree as ET

from idrive.session_log.data_types import LogRecord


class LogRecords(object):

    def __init__(self, xml_string=None):
        """Constructor"""

        self._records = set()

        if xml_string is not None:
            try:
                xml = ET.fromstring(xml_string)
            except ET.ParseError:
                xml = ET.fromstring('<records>' + xml_string + '</records>')

            for record in xml.iterfind('record'):
                self._records.add(LogRecord(record))

    def __iter__(self):
        """Iterator for the internal list"""

        return self._records.__iter__()

    def __getitem__(self, key):
        """Indexed access the internal list"""

        return list(self._records)[key]

    def add_record(self, record):
        """Add a record to the list."""

        if not isinstance(record, LogRecord):
            raise ValueError("Invalid record")

        self._records.add(record)

    def remove_record(self, record):
        """Remove a record."""

        if not isinstance(record, LogRecord):
            raise ValueError("Invalid record")

        self._records.remove(record)

    def __str__(self):
        """To get the string from included records."""

        records_str = ''
        for record in self._records:
            records_str += str(record)

        return records_str
