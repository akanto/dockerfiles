'''WebUI Controllers'''

import os
import glob

from flask import jsonify, session, redirect, request, render_template, url_for
from functools import wraps

from idrive.webui.core.models import PersistentObjManager
from idrive.webui.app.models.authenticate.check import check_authentication, \
    AUTH_REMOTE

__all__ = [
    os.path.basename(f)[:-3]
    for f in glob.glob(os.path.dirname(__file__) + '/*.py')
]

INTERNAL_ERROR_TXT = u'Internal application error. Check logs'


def logged_in(auth_state=AUTH_REMOTE):
    """Common function to check if user has logged in"""
    logged_in = False
    key_name = PersistentObjManager.KEY_NAME
    if not isinstance(auth_state, (tuple, list)):
        auth_state = (auth_state,)

    try:
        if check_authentication(session[key_name]) in auth_state:
            logged_in = True
    except KeyError:
        pass

    return logged_in


def require_login(auth_state=AUTH_REMOTE):
    """Check if user is logged in & send to login page if not"""

    if not logged_in(auth_state):
        '''If user is not logged in we either redirect to home
        or give them an error json'''
        url = url_for('login.index')
        if('X-Requested-With' in request.headers and
                request.headers['X-Requested-With'] == 'XMLHttpRequest'):
            return jsonify(redirect=url)
        return redirect(url)
