"""Backup/Restore page file operations."""

import os

from flask import request, session, render_template, jsonify, current_app

from . import bp_backup, bp_restore, POM, INTERNAL_ERROR_TXT
from idrive.webui.app.forms.backup_restore_browse import BackupRestoreBrowseForm
from idrive.webui.app.forms.delete import DeleteForm
from idrive.webui.app.forms.browse_search import BrowseSearchForm
from idrive.webui.app.forms.path import PathForm, PathsForm
from idrive.webui.app.forms.rename import RenameForm
from idrive.webui.app.helpers import jsonify_error
from idrive.webui.app.helpers.files import mark_files_in_set
from idrive.webui.app.helpers import sort
from idrive.webui.app.models import backup_restore_set
from idrive.webui.app.models import list_files, file_operations


@bp_backup.route('/files', endpoint='files', methods=['POST'],
                 defaults={'from_': 'local'})
@bp_restore.route('/files', endpoint='files', methods=['POST'],
                  defaults={'from_': 'remote'})
@bp_restore.route('/search', endpoint='search_P', methods=['POST'],
                  defaults={'from_': 'remote', 'is_search': True})
@bp_restore.route('/trash', endpoint='trash', methods=['POST'],
                  defaults={'from_': 'remote', 'is_search': True,
                            'is_trash': True})
def list_(from_, is_search=False, is_trash=False):
    """File, search & trash listing

    @param from_: Is this a "local" or "remote" listing?
    @param is_search: Set to True for search and trash requests
    @param is_trash: Set to True for trash requests only

    """

    if is_search:
        form = BrowseSearchForm(request.form)
        if is_trash:
            form.q.data = '*.*'
    else:
        form = BackupRestoreBrowseForm(request.form)

    if not form.validate():
        return jsonify_error(render_template('jsons/error.json', form=form))

    # params
    local = (from_ is 'local')
    file_lister = getattr(list_files, from_)
    key = session[POM.KEY_NAME]
    path = u'/' if is_search else form.path.data
    append = False if is_search else form.append.data
    template = False if is_search else form.template.data
    file_search_query = form.q.data if is_search else None
    file_list = None
    offset = None
    limit = None

    # only for search, limit listing to 400 entries at a time
    if is_search and not is_trash:
        offset = form.offset.data
        limit = 400

    br_set = set()
    try:
        # backup/restore set, to mark the files which are in set
        set_type = backup_restore_set.RESTORE_SET
        if local:
            set_type = backup_restore_set.BACKUP_SET

        set_ = backup_restore_set.get(key, set_type)
        br_set = set_.dir_entry_set
    except RuntimeError as err:
        current_app.logger.error(unicode(err))

    try:

        # Get the file list
        if is_search or is_trash:
            file_list = file_lister(key, path, file_search_query, is_trash,
                                    offset, limit)
        else:
            file_list = file_lister(key, path, refresh=form.reload.data)

        # mark the files in backup restore set
        if not is_trash:
            file_list = mark_files_in_set(file_list, br_set)

        # sort normal file listings by name first
        if not is_search:
            file_list.sort()

        # apply column sort
        if not is_search and form.sort_by.data:
            sorter = getattr(sort, form.sort_by.data)
            file_list.sort(key=sorter, reverse=(not form.sort_ascending.data))

    except ValueError as e:
        current_app.logger.debug(unicode(e))
        return jsonify_error(render_template('jsons/error.json', form=form,
                                             reason=unicode(e)))
    except RuntimeError as e:
        current_app.logger.error(unicode(e))
        return jsonify_error(render_template('jsons/error.json', form=form,
                                             reason=INTERNAL_ERROR_TXT))

    if template == 'filepicker':
        template = 'files/file_tree.html'
    else:
        template = 'files/file_list.html'

    content = render_template(template, file_list=file_list, backup=local,
                              append=append, search=is_search, trash=is_trash,
                              path=path, file_search_query=file_search_query,
                              offset=offset, limit=limit)

    return jsonify(html=content)


@bp_restore.route('/files/remove', endpoint='files/remove', methods=['POST'])
def remove():
    """Delete file from EVS."""

    form = DeleteForm(request.form)
    try:
        if not form.validate():
            raise ValueError()

        trash = form.trash.data
        delete_result = file_operations.remove_files(session[POM.KEY_NAME],
                                                     form.paths.data,
                                                     trash)
    except ValueError as e:
        current_app.logger.debug(unicode(e))
        return jsonify_error(render_template('jsons/error.json', form=form,
                                             reason=unicode(e)))
    except RuntimeError as err:
        current_app.logger.error(unicode(err))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))

    successes = []
    errors = []
    success_message = False
    error_message = False

    for result in delete_result.result:
        filename = result['name'].rstrip('/')

        if result['success']:
            successes.append(filename)
            # remove loaded files if normal delete
            if not trash:
                try:
                    list_files.remove_dir_entry(session[POM.KEY_NAME],
                                                filename,
                                                list_files.REMOTE)
                except KeyError:
                    pass
        else:
            errors.append(filename)

    outro = 'from the trash' if trash else None
    if successes:
        intro = 'Permanently deleted' if trash else 'Successfully deleted'
        success_message = render_template('files/multi_file_message.html',
                                          intro=intro, files=successes,
                                          outro=outro)
    if errors:
        error_message = render_template('files/multi_file_message.html',
                                        intro='Failed to delete', files=errors,
                                        outro=outro)

    return jsonify(results=delete_result.result,
                   success_message=success_message,
                   error_message=error_message)


@bp_restore.route('/trash/restore', methods=['POST'])
def trash_restore():
    """Restore file(s) from trash in EVS."""

    form = PathsForm(request.form)
    try:
        if not form.validate():
            raise ValueError()

        dir_entries = [path for path in form.paths.data]

        restore_result = file_operations.trash_restore(session[POM.KEY_NAME],
                                                       dir_entries)
    except ValueError as e:
        current_app.logger.debug(unicode(e))
        return jsonify_error(render_template('jsons/error.json', form=form,
                                             reason=unicode(e)))
    except RuntimeError as e:
        current_app.logger.error(unicode(e))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))

    success_files = []
    error_files = []
    success_message = False
    error_message = False
    for result in restore_result.result:
        if result['success']:
            success_files.append(result['name'])
        else:
            error_files.append(result['name'])

    if success_files:
        success_message = render_template('files/multi_file_message.html',
                                          intro='Restored',
                                          files=success_files,
                                          outro='from the trash')
    if error_files:
        error_message = render_template('files/multi_file_message.html',
                                        intro='Failed to restore',
                                        files=error_files,
                                        outro='from the trash')

    return jsonify(results=restore_result.result,
                   success_message=success_message,
                   error_message=error_message)


@bp_restore.route('/files/versions', methods=['POST'])
def versions():
    """List versions for EVS file."""

    form = PathForm(request.form)

    try:
        if not form.validate():
            raise ValueError()

        dir_entry = list_files.get_dir_entry(session[POM.KEY_NAME],
                                             form.path.data,
                                             list_files.REMOTE)
        file_versions = file_operations.get_versions(session[POM.KEY_NAME],
                                                     dir_entry)
        file_versions.reverse()
    except ValueError as e:
        current_app.logger.debug(unicode(e))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=unicode(e),
                                             form=form))
    except (KeyError, RuntimeError) as e:
        current_app.logger.error(unicode(e))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))

    versions_content = render_template('files/file_list.html',
                                       file_list=file_versions,
                                       versions=True)
    return jsonify(html=render_template('files/modals/versions.html',
                                        versions_content=versions_content,
                                        count=len(file_versions),
                                        path=form.path.data))


@bp_restore.route('/files/rename', methods=['POST'])
def rename():
    """Rename file/folder"""
    form = RenameForm(request.form)

    try:
        if not form.validate():
            raise ValueError()

        key = session[POM.KEY_NAME]
        old_dir_entry = list_files.get_dir_entry(key, form.old.data,
                                                 list_files.REMOTE)

        result = file_operations.rename(key, old_dir_entry,
                                        form.new.data)

        # fetch the parent directory's file list
        parent = os.path.dirname(result.newname)
        file_list = list_files.remote(key, parent)

    except ValueError as e:
        current_app.logger.debug(unicode(e))
        return jsonify_error(render_template('jsons/error.json', form=form,
                                             reason=unicode(e).capitalize()))
    except (KeyError, RuntimeError) as e:
        current_app.logger.error(unicode(e))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))

    content = render_template('files/file_list.html',
                              file_list=file_list,
                              append=(False if parent == os.sep else True),
                              restore=True)

    return jsonify(html=content, old=result.oldname, new=result.newname)
