"""For running backup/restore operation and progress update."""

from __future__ import division

import datetime

from . import bp_backup, bp_restore, POM, INTERNAL_ERROR_TXT
from flask import render_template, session, jsonify, current_app
from idrive.scheduler.data_types import JobSchedule
from idrive.webui.app.helpers import jsonify_error
from idrive.webui.app.models import schedule_manager, list_files


@bp_backup.route('/operation/run', endpoint='operation/run', methods=['GET'],
                 defaults={'backup': True})
@bp_restore.route('/operation/run', endpoint='operation/run', methods=['GET'],
                  defaults={'backup': False})
def run(backup):
    """Start an immediate backup/restore operation."""

    # Remove / from POM cache so that remote list will reload with
    #  current back up.
    if backup:
        try:
            list_files.remove_dir_entry(session[POM.KEY_NAME], '/',
                                        list_files.REMOTE)
        except KeyError:
            pass

    # Schedule a one time backup/restore 2 seconds later
    two_sec_later = datetime.datetime.now() + datetime.timedelta(0, 2)

    # vars
    key = session[POM.KEY_NAME]
    job_schedule = JobSchedule([], two_sec_later.time())

    try:
        if backup:
            schedule_manager.add_backup_job(key, job_schedule)
        else:
            schedule_manager.add_restore_job(key, job_schedule)
    except (ValueError, RuntimeError) as err:
        current_app.logger.error(unicode(err))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))

    return jsonify(success=True)


@bp_backup.route('/operation/progress', endpoint='operation/progress',
                 methods=['GET'], defaults={'backup': True})
@bp_restore.route('/operation/progress', endpoint='operation/progress',
                  methods=['GET'], defaults={'backup': False})
def progress(backup):
    """Get progress of a backup/restore operation."""

    try:
        key = session[POM.KEY_NAME]
        if backup:
            progress = schedule_manager.get_backup_job_progress(key)
        else:
            progress = schedule_manager.get_restore_job_progress(key)
    except (ValueError, RuntimeError) as err:
        current_app.logger.error(unicode(err))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))

    in_progress = True if progress is not None else False
    error_progress = False
    if progress is not None:
        error_progress = [p for p in progress if p.error]
        progress = [p for p in progress if not p.error]

    total_progress_html = False
    success_html = False
    error_html = False

    if progress is None or len(progress) > 0:
        success_html = render_template('operations/progress_success.html',
                                       backup=backup,
                                       progress=progress)

    if progress:
        total_progress_html = \
            render_template('operations/total_progress.html',
                            transferred=progress[0].transferred_totalsize,
                            total=progress[0].totalsize)

    if error_progress:
        error_html = render_template('operations/progress_error.html',
                                     backup=backup,
                                     errors=error_progress)

    return jsonify(in_progress=in_progress,
                   total_progress_html=total_progress_html,
                   success_html=success_html, error_html=error_html)


@bp_backup.route('/operation/stop', endpoint='operation/stop',
                 methods=['GET'], defaults={'backup': True})
@bp_restore.route('/operation/stop', endpoint='operation/stop',
                  methods=['GET'], defaults={'backup': False})
def stop(backup):
    """Stop an already running backup/restore."""

    try:
        key = session[POM.KEY_NAME]
        if backup:
            schedule_manager.cancel_backup_job(key)
        else:
            schedule_manager.cancel_restore_job(key)
    except (ValueError, RuntimeError) as err:
        current_app.logger.error(unicode(err))
        return jsonify_error(render_template('jsons/error.json',
                                             reason=INTERNAL_ERROR_TXT))

    return jsonify(success=True)
