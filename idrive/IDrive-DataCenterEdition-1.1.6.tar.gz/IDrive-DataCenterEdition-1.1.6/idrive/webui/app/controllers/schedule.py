"""Scheduler page"""

import json

from flask import Blueprint, render_template, session, jsonify, request, \
    current_app, Response

from idrive.scheduler.data_types import JobSchedule
from idrive.webui.app.controllers import require_login, INTERNAL_ERROR_TXT
from idrive.webui.app.forms.schedule import ScheduleForm
from idrive.webui.app.helpers import jsonify_error, time
from idrive.webui.app.models import schedule_manager, user_settings
from idrive.webui.app.models.schedule_manager import BACKUP_JOB
from idrive.webui.core.models import PersistentObjManager

bp = Blueprint('scheduler', __name__, url_prefix='/schedule')
bp.before_request(require_login)

POM = PersistentObjManager()


@bp.route('', methods=['GET'])
def index():
    """Scheduler index page."""
    # quota
    user_quota = user_settings.get(session[POM.KEY_NAME], True).QUOTA

    error = None
    schedule = get(BACKUP_JOB)
    if isinstance(schedule, Response):
        schedule = json.loads(schedule.get_data())['html']
    else:
        error = json.loads(schedule[0])['errors']['reason']
        schedule = None

    return render_template('scheduler/index.html',
                           scheduler=True,
                           quota=user_quota,
                           schedule=schedule,
                           error=error)


@bp.route('/backup', methods=['GET'], defaults={'sched_type': BACKUP_JOB})
def get(sched_type):
    """Get currently stored schedule.

    Note: for now only backup schedules are returned. Just defining a
    new blueprint should be able to handle restore schedules as well.

    """

    key = session[POM.KEY_NAME]
    error = None

    try:
        jobs = schedule_manager.get_jobs(key)
        settings = user_settings.get(key, True)
    except ValueError as e:
        current_app.logger.error(unicode(e))
        error = unicode(e)
    except (KeyError, RuntimeError) as e:
        current_app.logger.error(unicode(e))
        error = INTERNAL_ERROR_TXT

    if error is not None:
        return jsonify_error(render_template('jsons/error.json',
                                             reason=error))

    # vars
    days = None
    start_time = None
    start_time_format = None
    cutoff_time = None
    cutoff_time_format = None
    next_run_time = None
    notify_emails = settings.BACKUP.notify_emails
    notify_on_success = settings.BACKUP.notify_on_success
    notify_on_error = settings.BACKUP.notify_on_error

    if jobs is not None:
        for job in jobs:
            if sched_type == job[0] and len(job[1].days) != 0:
                days = job[1].days
                start_time = job[1].start_time.strftime('%X')
                start_time_format = job[1].start_time.strftime('%I:%M %p')
                cutoff_time = job[1].cutoff_time.strftime('%X') \
                    if job[1].cutoff_time is not None else None
                cutoff_time_format = job[1].cutoff_time.strftime('%I:%M %p') \
                    if job[1].cutoff_time is not None else None
                next_run_time = \
                    job[1].next_run_time().strftime('%A, %B %d at %I:%M %p')

    return jsonify(html=render_template('scheduler/schedule.html', days=days,
                                        start_time=start_time,
                                        start_time_format=start_time_format,
                                        cutoff_time=cutoff_time,
                                        cutoff_time_format=cutoff_time_format,
                                        next_run_time=next_run_time,
                                        notify_emails=notify_emails,
                                        notify_on_success=notify_on_success,
                                        notify_on_error=notify_on_error),
                   days=days, start_time=start_time, cutoff_time=cutoff_time,
                   next_run_time=next_run_time,
                   start_time_format=start_time_format)


@bp.route('/backup', methods=['POST'], defaults={'sched_type': BACKUP_JOB})
def update(sched_type):
    """Add/Update/Delete a schedule.

    Note: For now, only backup schedules are handled.

    POST Parameters:
    @param days: - array of day integers. 0 is Monday. 6 is Sunday. To delete
        schedule, send nothing.
    @param start_time: "HH:MM:SS", required for add/update
    @param cutoff_time: "HH:MM:SS"
    @param notify_emails: array of email addresses. To remove all email
        addresses, send nothing
    @param notify_on_success: (optional) "yes"
    @param notify_on_error: (optional) "yes"

    """

    key = session[POM.KEY_NAME]
    form = ScheduleForm(request.form)
    error = False

    if form.validate():
        try:
            # delete schedule request
            if not form.days.data:
                try:
                    schedule_manager.remove_backup_job(key)
                except KeyError:
                    pass  # no job exists to remove

            # update schedule request
            else:
                start_time = time.time_from_hms(form.start_time.data)

                cutoff = None
                if form.cutoff_time.data:
                    cutoff = time.time_from_hms(form.cutoff_time.data)

                job_schedule = JobSchedule(form.days.data, start_time, cutoff)
                schedule_manager.add_backup_job(key, job_schedule)

            # notification settings are updated separately
            section = 'BACKUP'
            prefix = 'notify_'
            notify_emails = ', '.join(form.notify_emails.data)

            user_settings.update_remote(key, section, prefix + 'emails',
                                        notify_emails)
            user_settings.update_remote(key, section, prefix + 'on_success',
                                        form.notify_on_success.data)
            user_settings.update_remote(key, section, prefix + 'on_error',
                                        form.notify_on_error.data)

        except (KeyError, ValueError, RuntimeError) as e:
            current_app.logger.error(unicode(e))
            error = INTERNAL_ERROR_TXT

    if form.errors or error:
        return jsonify_error(render_template('jsons/error.json', form=form,
                                             reason=error))

    return get(BACKUP_JOB)
