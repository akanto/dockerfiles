'''ldb.webui.app.controllers.proxy'''

from flask import Blueprint, current_app, flash, render_template, request, \
    redirect, session

from idrive.webui.app.controllers import require_login, INTERNAL_ERROR_TXT
from idrive.webui.app.forms.proxy import ProxyForm
from idrive.webui.app.models import user_settings
from idrive.webui.app.models.authenticate.check import AUTH_LOCAL, AUTH_REMOTE
from idrive.webui.core.models.persistent_obj_manager import PersistentObjManager

bp = Blueprint('proxy', __name__, url_prefix='/settings/proxy')
bp.before_request(lambda: require_login((AUTH_LOCAL, AUTH_REMOTE)))

POM = PersistentObjManager()


@bp.route('', methods=('GET', 'POST'))
def index():
    '''
    network proxy index & update page
    '''
    error = None
    key = session[POM.KEY_NAME]
    form = ProxyForm(request.form, data=request.args.to_dict())

    try:
        settings = user_settings.get(key, True)
    except (ValueError, RuntimeError) as e:
        current_app.logger.error(unicode(e))
        if isinstance(e, ValueError):
            error = unicode(e)
        else:
            error = INTERNAL_ERROR_TXT
        flash(error, 'notify_danger')
    else:
        form = ProxyForm(request.form, data=request.args.to_dict(),
                         **settings.as_dict())
        if request.method == 'POST' and form.validate():
            try:
                for field in form:
                    if field.name == 'next':
                        continue
                    # parse the section/key from the name
                    field_name = field.name.split('_')
                    section = field_name.pop(0)
                    name = '_'.join(field_name)

                    user_settings.update_local(key, section, name, field.data)

            except (ValueError, RuntimeError) as e:
                current_app.logger.error(unicode(e))
                if isinstance(e, ValueError):
                    error = unicode(e)
                else:
                    error = INTERNAL_ERROR_TXT

            if error is None:
                flash(u'Proxy updated successfully', 'notify_success')
                return redirect(form.next.data)

            flash(error, 'notify_danger')

    return render_template('settings/proxy.html', form=form)
