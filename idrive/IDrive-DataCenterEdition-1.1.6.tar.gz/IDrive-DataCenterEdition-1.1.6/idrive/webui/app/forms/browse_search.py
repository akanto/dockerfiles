'''Browsing search form'''

from idrive.webui.app.forms.search_form import SearchForm
from wtforms.validators import Optional, NumberRange
from wtforms.fields.core import IntegerField


class BrowseSearchForm(SearchForm):
    '''Search form for browsing'''

    offset = IntegerField('Offset', [Optional(), NumberRange(min=0)],
                          default=0)
