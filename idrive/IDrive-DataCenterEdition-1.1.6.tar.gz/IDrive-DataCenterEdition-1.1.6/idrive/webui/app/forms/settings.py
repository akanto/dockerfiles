''' Settings '''

from wtforms import Form, IntegerField, FormField
from wtforms.validators import NumberRange, InputRequired

from idrive.webui.app.forms.fields.failure_threshold import FailureThresholdField
from idrive.webui.app.forms.validators.settings import LocalSetting, \
    SETTING_FLAGS


class SettingsForm(Form):
    '''
    Settings Form

    Note: fields here are responsible for noting what type of setting they
    are so that we update the correct file. Pass in one of the *Setting()
    objects above as a validating function for the field to flag it as such.

    Then to reference it in the code:

        field_object.flags.remote
    '''

    LOCAL_upload_bandwidth = \
        IntegerField(u'Backup Bandwidth Usage',
                     validators=[LocalSetting(), InputRequired(),
                                 NumberRange(0, 100, ('Must be a number '
                                                      'between 0 and 100'))],
                     description=("Percent of the computer's bandwidth to use "
                                  'during backup'),
                     default=100)

    APPLICATION_failure_threshold = FailureThresholdField(
        u'Backup Failure Threshold',
        description=('At what point will the backup be considered a failure? '
                     'Choose either a number of files or a percentage '
                     'of all files backed up. A value of "0" means any '
                     'errors will be considered a failure'))

    def __init__(self, formdata=None, obj=None, prefix='', **kwargs):
        '''
        constructor
        '''
        super(SettingsForm, self).__init__(formdata, obj, prefix, **kwargs)

        self._verify_flags(self)

    def _verify_flags(self, form):
        '''
        ensure that the fields added here have a flag set to indicate what
        type of setting they are
        '''
        for field in form:
            if isinstance(field, FormField):
                self._verify_flags(field)
            else:
                found = False
                for flag in SETTING_FLAGS.values():
                    if flag in field.flags:
                        found = True

                if not found:
                    raise ValueError(field.label.text +
                                     ' must have a settings flag set')
