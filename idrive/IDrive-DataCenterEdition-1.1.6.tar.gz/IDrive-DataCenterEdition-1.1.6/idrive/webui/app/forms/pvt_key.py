from wtforms import Form, PasswordField, validators


class PvtKeyForm(Form):
    '''Pvt Form'''

    pvtkey = PasswordField(u'Private Encryption Key', [
        validators.InputRequired(),
        validators.Length(min=4)
    ])
