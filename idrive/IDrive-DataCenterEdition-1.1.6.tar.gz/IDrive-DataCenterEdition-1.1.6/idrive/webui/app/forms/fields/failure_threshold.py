'''Custom field for handling failure threshold'''

from wtforms import Form, FormField, IntegerField, RadioField
from wtforms.fields import _unset_value
from wtforms.widgets import HTMLString, html_params, TextInput, ListWidget
from wtforms.validators import NumberRange, ValidationError

from idrive.webui.app.forms.validators.settings import LocalSetting

NUMBER = ''
PERCENT = 'pc'
NUMBER_TYPE_CHOICES = [(NUMBER, 'Files Failed'), (PERCENT, 'Percent Failed')]


class _FailureThresholdWidget(object):

    def __call__(self, field, **kwargs):
        """Simple widget to render all fields in failure threshold"""
        kwargs.setdefault('id', field.id)
        kwargs.setdefault('class', 'failure-threshold-widget row')
        html = ['<div %s>' % html_params(**kwargs)]
        for subfield in field:
            html.append(subfield())
        html.append('</div>')
        return HTMLString(u''.join(html))


class _FailureThresholdNumberWidget(TextInput):

    def __call__(self, field, **kwargs):
        """Renders number part of failure threshold"""
        kwargs.setdefault('id', field.id)
        kwargs.setdefault('class', 'col-sm-4')
        html = ['<div %s>' % html_params(**kwargs)]
        html.append(
            super(_FailureThresholdNumberWidget, self).__call__(
                field, type='number', min='0', step='1',
                class_='form-control'))
        html.append('</div>')
        return HTMLString(u''.join(html))


class _FailureThresholdTypeWidget(ListWidget):

    def __call__(self, field, **kwargs):
        """Renders number part of failure threshold"""
        kwargs.setdefault('id', field.id)
        kwargs.setdefault('class', 'col-sm-8')
        html = ['<div %s>' % html_params(**kwargs)]
        html.append(
            super(_FailureThresholdTypeWidget, self).__call__(
                field, class_='list-inline failure-threshold-widget-radio'))
        html.append('</div>')
        return HTMLString(u''.join(html))


class _FailureThresholdForm(Form):
    number = IntegerField(u'Number',
                          validators=[LocalSetting(), NumberRange(min=0)],
                          widget=_FailureThresholdNumberWidget(),
                          default=0)

    number_type = \
        RadioField(u'Type', validators=[LocalSetting()],
                   choices=NUMBER_TYPE_CHOICES,
                   widget=_FailureThresholdTypeWidget(prefix_label=False),
                   default=NUMBER)

    def validate_number(self, field):
        if self.number_type.data == PERCENT and int(field.data) > 100:
            raise ValidationError('Percentage cannot be greater than 100%')


class FailureThresholdField(FormField):
    widget = _FailureThresholdWidget()

    def __init__(self, label='', validators=None, **kwargs):
        super(FailureThresholdField, self).__init__(_FailureThresholdForm,
                                                    label, validators,
                                                    **kwargs)

    def process(self, formdata, data=_unset_value):
        """Sets the form values properly from the incoming data
        """
        prefix = self.name + self.separator
        kwargs = {}
        if data is not _unset_value:
            if data.endswith(PERCENT):
                kwargs['number'] = data.rstrip(PERCENT)
                kwargs['number_type'] = PERCENT
            else:
                kwargs['number'] = data
                kwargs['number_type'] = NUMBER

        self.form = self.form_class(formdata, prefix=prefix, **kwargs)

    @property
    def data(self):
        return str(self.form.number.data) + self.form.number_type.data
