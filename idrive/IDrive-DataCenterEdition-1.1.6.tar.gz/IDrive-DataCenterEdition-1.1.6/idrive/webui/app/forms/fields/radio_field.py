'''ldb.webui.app.forms.fields.radio_field'''

from wtforms.fields import RadioField

from idrive.webui.app.forms.widgets.radio import LDBRadioWidget


class LDBRadioField(RadioField):
    '''a radio field that uses a better rendering widget'''

    widget = LDBRadioWidget()
