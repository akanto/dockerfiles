'''ldb.webui.app.forms.fields.proxy_choice'''

from idrive.webui.app.forms.fields.radio_field import LDBRadioField


class ProxyChoice(LDBRadioField):

    def post_validate(self, form, validation_stopped):
        '''If this field's data is anything other than "manual" we want to
        clear all the remaining proxy related fields
        '''
        if self.data != 'manual':
            proxy_fields = ['NETWORKPROXY_host', 'NETWORKPROXY_port',
                            'NETWORKPROXY_username', 'NETWORKPROXY_password']
            for proxy_field in proxy_fields:
                proxy_field = form._fields.get(proxy_field)
                if proxy_field is None:
                    raise Exception('no field named "%s" in form' %
                                    proxy_field)
                proxy_field.raw_data = ''
                proxy_field.data = ''
