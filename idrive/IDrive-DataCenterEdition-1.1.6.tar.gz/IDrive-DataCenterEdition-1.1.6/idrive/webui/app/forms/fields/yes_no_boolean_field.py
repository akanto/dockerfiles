'''Custom Yes/No Boolean Field'''

from wtforms import BooleanField


YES = u'yes'
NO = u'no'


class YesNoBooleanField(BooleanField):

    def process_data(self, value):
        self.data = YES if str(value) == YES else NO

    def process_formdata(self, valuelist):
        if not valuelist or valuelist[0] in self.false_values:
            self.data = NO
        else:
            self.data = YES

    def _value(self):
        return YES
