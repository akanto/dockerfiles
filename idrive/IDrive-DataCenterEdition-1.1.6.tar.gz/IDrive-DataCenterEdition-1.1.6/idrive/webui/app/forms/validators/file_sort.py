'''Validator for sorting file lists'''

from wtforms.validators import ValidationError

from idrive.webui.app.helpers import sort


class FileSort(object):
    """Validates that we can sort on the given field"""

    def __call__(self, form, field):
        if not hasattr(sort, field.data):
            raise ValidationError('Invalid sort column')
