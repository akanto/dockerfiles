'''Backup/Restore Browse Form'''

from wtforms import BooleanField, StringField
from wtforms.validators import Optional, AnyOf

from idrive.webui.app.forms.path import DefaultPathForm
from idrive.webui.app.forms.validators.file_sort import FileSort


class BackupRestoreBrowseForm(DefaultPathForm):
    '''Inherits the path form field'''

    append = BooleanField('Append', [Optional()], default=False)

    reload = BooleanField('Reload', [Optional()], default=False)

    template = StringField('Template', [Optional(), AnyOf(['filepicker'])],
                           default=False)

    sort_by = StringField('Sort By', [Optional(), FileSort()], default=False)

    sort_ascending = BooleanField('Sort Ascending', [Optional()], default=True)
