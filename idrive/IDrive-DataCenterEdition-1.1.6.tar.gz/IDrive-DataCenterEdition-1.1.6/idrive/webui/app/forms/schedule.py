'''schedule form'''

from wtforms import Form, FieldList, StringField, IntegerField
from wtforms.validators import Email, NumberRange, Optional

from idrive.webui.app.forms.fields.yes_no_boolean_field import \
    YesNoBooleanField, YES
from idrive.webui.app.forms.validators import OptionalUnless, Time, UniqueList, \
    OccursAfter


class ScheduleForm(Form):
    '''Schedule Form'''

    days = FieldList(IntegerField(u'Days', [NumberRange(min=0, max=6)]))

    start_time = StringField(u'Start Time', [OptionalUnless('days'), Time()])

    cutoff_time = StringField(u'Cutoff Time', [Optional(), Time(),
                                               OccursAfter('start_time')])

    notify_emails = \
        FieldList(StringField(u'Notification Recipient', [Email()]),
                  label=u'Notification Recipients',
                  validators=[OptionalUnless(['notify_on_success',
                                              'notify_on_error'],
                                             required_value=YES),
                              UniqueList()])

    notify_on_success = YesNoBooleanField(u'Notify on Success')

    notify_on_error = YesNoBooleanField(u'Notify on Error')
