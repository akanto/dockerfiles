'''Jinja extensions'''

from idrive.webui.app import app

app.jinja_env.add_extension('jinja2.ext.do')
