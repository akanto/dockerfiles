from idrive.webui.app import app
from idrive.webui.app.controllers import index, login, logout, backup_restore, \
    schedule, logs, settings, proxy

# register route areas
app.register_blueprint(login.bp)
app.register_blueprint(logout.bp)
app.register_blueprint(index.bp)
app.register_blueprint(backup_restore.bp_backup)
app.register_blueprint(backup_restore.bp_restore)
app.register_blueprint(schedule.bp)
app.register_blueprint(logs.bp)
app.register_blueprint(settings.bp)
app.register_blueprint(proxy.bp)
