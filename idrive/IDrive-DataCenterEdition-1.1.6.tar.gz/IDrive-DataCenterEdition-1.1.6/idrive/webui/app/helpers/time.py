'''time helper functions'''

import datetime


def time_from_hms(hhmmss):
    '''Parse time from 24 hour HH:MM:SS string

    @return: datetime.time object
    '''
    h, m, s = [int(x) for x in hhmmss.split(':')]
    return datetime.time(h, m, s)
