'''WebUI Helpers'''

from flask import request

HTTP_ERROR_CODE = 422
JSON_MIMETYPE = {'Content-Type': 'application/json'}


def jsonify_error(error_json):
    """Helper function to return a 3 member tuple for a json error."""

    return error_json, HTTP_ERROR_CODE, JSON_MIMETYPE


def is_ajax():
    """is the current request an ajax request?"""
    return ('X-Requested-With' in request.headers and
            request.headers['X-Requested-With'] == 'XMLHttpRequest')
