'''file helpers'''

import os
import re

_TYPE_EXCEL = re.compile(
    r'[^.]+\.(xl(s[mbx]?|r)?|xlt[mx]|o[dt]s|gsheet|numbers|123|csv)$',
    re.IGNORECASE)
_TYPE_PDF = re.compile(r'[^.]+\.pdf$', re.IGNORECASE)
_TYPE_WORD = re.compile(r'[^.]+\.(docx?|odt|pages|wp[ds])$', re.IGNORECASE)
_TYPE_ARCHIVE = re.compile(
    r'[^.]+\.(deb|arc|war|bz2?|b?zip|7z|rpm|gz(ip)?|ace|rar|tz)$',
    re.IGNORECASE)
_TYPE_IMAGE = re.compile(
    r'[^.]+\.(p(ng|sd)|jpe?g|gif|bmp|tiff?|cpt|icon|raw|svg)$', re.IGNORECASE)
_TYPE_AUDIO = re.compile(
    r'[^.]+\.(oga|midi?|wma|mp3|wav|ogg|flac|aac|aiff|m4p)$', re.IGNORECASE)
_TYPE_TEXT = re.compile(r'[^.]+\.(log|err|txt|rtf|md|rst)$', re.IGNORECASE)
_TYPE_CODE = re.compile((r'[^.]+\.(h|c(s|pp|gi)?|mk?|java|swift|e?rb|py|go|'
                         r'js(on)?|php|html|s?css|aspx?|xml|sh)$'),
                        re.IGNORECASE)
_TYPE_POWERPOINT = re.compile(r'[^.]+\.(pptx?|ppsx?|o[dt]p)$', re.IGNORECASE)
_TYPE_VIDEO = re.compile(
    r'[^.]+\.(3gp2?|mkv|wmv|mp(e?g|4)|mov|divx|ogv|avi|gifv)$', re.IGNORECASE)


def mark_files_in_set(files, set_):
    '''Mark all dir entries if they are in the set or not'''
    for file_ in files:
        for set_item in set_:
            # this item in the backup set
            if file_ == set_item:
                file_.set_status = 'yes'
                break

            # folder has children in the backup set
            elif (not file_.isfile and
                  set_item.name.startswith(file_.name + os.sep)):

                file_.set_status = 'children'
                break

            # item has a parent in the set
            elif file_.name.startswith(set_item.name + os.sep):
                file_.set_status = 'parent'
                break

            # not in set
            else:
                file_.set_status = 'no'
        # no files in set
        else:
            file_.set_status = 'no'

    return files


def get_icon(item):
    '''
    returns the name of the fontawesome icon name for a particular file type
    '''
    if not item.isfile:
        return 'folder-o'
    elif _TYPE_EXCEL.search(item.name):
        return 'file-excel-o'
    elif _TYPE_PDF.search(item.name):
        return 'file-pdf-o'
    elif _TYPE_WORD.search(item.name):
        return 'file-word-o'
    elif _TYPE_ARCHIVE.search(item.name):
        return 'file-archive-o'
    elif _TYPE_IMAGE.search(item.name):
        return 'file-image-o'
    elif _TYPE_AUDIO.search(item.name):
        return 'file-audio-o'
    elif _TYPE_TEXT.search(item.name):
        return 'file-text-o'
    elif _TYPE_CODE.search(item.name):
        return 'file-code-o'
    elif _TYPE_POWERPOINT.search(item.name):
        return 'file-powerpoint-o'
    elif _TYPE_VIDEO.search(item.name):
        return 'file-video-o'
    return 'file-o'
