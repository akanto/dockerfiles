"""Authentication related data types."""

from idrive.webui.app.models.authenticate.data_types.sys_login_data import \
    SysLoginData

from idrive.webui.app.models.authenticate.data_types.remote_login_data import \
    RemoteLoginData
