'''
Quota model
'''

# imports
import idrive.proxy.interface as proxy

from idrive.core.evs.account.data_types import QuotaError
from idrive.webui.core.models import PersistentObjManager
from idrive.webui.app.models.authenticate.data_types import SysLoginData, \
    RemoteLoginData

# vars
POM = PersistentObjManager()

_QUOTA_CMD = 'quota'
_QUOTA_KEY = 'quota'


def get_quota(key, refresh=False):
    """Get user's quota information

    @return: Quota object with the following properties:
        MAX_QUOTA - user's total available quota
        MAX_QUOTA_FORMAT - Formatted string ie - "50 GB"
        USED_QUOTA - currently used storage
        USED_QUOTA_FORMAT - Formatted string ie - "16.5 GB"
        FILE_COUNT - total number of files stored by the user
        PERCENT - How much of the total quota has been used as a percent

    @raise ValueError: Error from EVS side
    @raise RuntimeError: All other error

    """
    # login data
    try:
        sys_login_data = POM.get(key, type(SysLoginData()).__name__)
        remote_login_data = POM.get(key, type(RemoteLoginData()).__name__)
    except KeyError:
        raise RuntimeError("'SysLoginData' not set")

    # try to get quota from the pom first. if we get it, we're done
    if not refresh:
        try:
            return POM.get(key, _QUOTA_KEY)
        except KeyError:
            pass

    # params
    username = sys_login_data.username
    password = sys_login_data.password
    remote_username = remote_login_data.username
    remote_password = remote_login_data.password
    pvtkey = remote_login_data.pvtkey

    # quota
    result = proxy.passthru(username, password, _QUOTA_CMD,
                            {'params': (remote_username, remote_password,
                                        pvtkey)})

    if isinstance(result, QuotaError):
        raise ValueError(str(result.message))
    elif isinstance(result, Exception):
        raise RuntimeError(str(result))
    # cache quota for later
    else:
        POM.set(key, _QUOTA_KEY, result)

    return result
