"""IBL web interface package."""

import os
import pwd

from idrive.conf.settings import GlobalSettings

NAME = 'Web Server'
DESC = ('The {} displays the web interface for managing backups & '
        'restores on your system.').format(NAME)
# controls whether or not web server will run in debug mode
DEBUG = False

# Set the python_eggs directory here so that nobody has access to it
if os.getuid() == 0:
    _G = GlobalSettings()

    try:
        user = _G.WEBAPP.user
    except (AttributeError, ValueError):
        user = 'nobody'

    python_egg_cache = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    '.python-eggs')
    if not os.path.exists(python_egg_cache):
        os.makedirs(python_egg_cache, mode=0755)

    os.chown(python_egg_cache,
             pwd.getpwnam(user).pw_uid,
             pwd.getpwnam(user).pw_gid)

    os.environ['PYTHON_EGG_CACHE'] = python_egg_cache
