:orphan:

|project|
=========

Backup & Restore for your Linux server powered by |product|.

Installation
------------

To install the application, execute the following from a terminal prompt::

    $ sudo ./ez_install.sh

If the setup fails, you may also check out ``docs/install.txt`` for additional
tips and troubleshooting information as well as some platform specific
workarounds and caveats.

Running the Application
-----------------------

Once the application is installed on your machine, you can start it from the
command line by running:

.. parsed-literal::

    $ sudo /usr/local/bin/|project_exe| start

You will then be able to access the application via your web browser by
visiting https://127.0.0.1 (from the same computer) or the computer's IP address
at the port number you specified while running the start command.

The application can be stopped by running:

.. parsed-literal::

    $ sudo /usr/local/bin/|project_exe| stop

For a list of all commands, type:

.. parsed-literal::

    $ sudo /usr/local/bin/|project_exe| -h

Documentation & FAQs
--------------------

All documentation is in the ``docs/`` directory. If you are installing the
program for the first time or have other questions, we recommend checking there
first to see if your issue has been answered there.

Support
-------

If you have any further questions or need additional help, we encourage you to
contact our support staff at anytime:

Via Website
    |url_support|

Via Phone
    |phone_support_usa| (within US)

    |phone_support_world| (outside US)

Via Email
    |email_support|

--------------------------

Thanks! We hope you enjoy using the program.
